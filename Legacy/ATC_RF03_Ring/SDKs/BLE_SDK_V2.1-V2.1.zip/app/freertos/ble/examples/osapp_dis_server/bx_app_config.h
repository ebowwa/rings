#ifndef BX_APP_CONFIG_H_
#define BX_APP_CONFIG_H_

#define CFG_PRF_DISS
#define CFG_PRF_BXOTAS
//#define DEBUGGER_ATTACHED 0

#endif
