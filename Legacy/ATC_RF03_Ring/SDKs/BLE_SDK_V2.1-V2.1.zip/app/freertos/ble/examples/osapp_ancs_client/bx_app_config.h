#ifndef BX_APP_CONFIG_H_
#define BX_APP_CONFIG_H_

#define CFG_PRF_ANCC
#define CFG_PRF_GATTSC
#endif
