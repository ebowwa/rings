#ifndef NETWORK_RX_PROCESS_H_
#define NETWORK_RX_PROCESS_H_
#include "network_pdu.h"


void network_rx_process_start(network_pdu_rx_t *buf);

#endif
