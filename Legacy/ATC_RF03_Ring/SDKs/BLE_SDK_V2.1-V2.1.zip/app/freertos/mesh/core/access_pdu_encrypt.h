#ifndef ACCESS_PDU_ENCRYPT_H_
#define ACCESS_PDU_ENCRYPT_H_
#include "upper_pdu.h"

void access_pdu_encrypt_start(access_pdu_tx_t *pdu,void (*callback)());

#endif
