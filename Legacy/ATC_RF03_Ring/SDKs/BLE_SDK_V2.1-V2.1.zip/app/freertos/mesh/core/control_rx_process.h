#ifndef CONTROL_RX_PROCESS_H_
#define CONTROL_RX_PROCESS_H_
#include "upper_pdu.h"

void control_pdu_rx_process(upper_pdu_rx_t *control_upper_pdu);


#endif



