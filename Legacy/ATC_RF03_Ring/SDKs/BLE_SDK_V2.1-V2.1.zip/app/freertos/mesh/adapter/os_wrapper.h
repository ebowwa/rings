#ifndef OS_WRAPPER_H_
#define OS_WRAPPER_H_

void os_enter_critical(void);

void os_exit_critical(void);

#endif
