/*
 * mesh_gatt_cfg.c
 *
 *  Created on: 2018��8��2��
 *      Author: huichen
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "osapp_config.h"

#include "mesh_gatt_cfg.h"


///**
// ****************************************************************************************
// * @brief The Mesh Gatt att_mtu max size to peer device.
// *
// * @param[in] conn_index  gatt connect index.
// *
// * @return The max gatt mtu size.
// *
// ****************************************************************************************
// */
//uint16_t mesh_gatt_get_att_mtu_size(uint16_t conn_index)
//{
//
//}
//
//

