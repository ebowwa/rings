#ifndef MESH_TTL_TEST_H_
#define MESH_TTL_TEST_H_



bool  network_rx_ttl_check(network_pdu_rx_t *pdu,network_pdu_packet_u *ptr);


#endif

