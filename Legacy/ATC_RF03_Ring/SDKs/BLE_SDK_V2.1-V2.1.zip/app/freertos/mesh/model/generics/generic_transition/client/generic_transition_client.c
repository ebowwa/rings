#include "osapp_config.h"
#include "generic_transition_client.h"


void generic_default_transition_time_status_rx(mesh_elmt_t *elmt,model_base_t *model,access_pdu_rx_t *pdu)
{
    LOG(3,"generic_default_transition_time_status_rx\n");
}



