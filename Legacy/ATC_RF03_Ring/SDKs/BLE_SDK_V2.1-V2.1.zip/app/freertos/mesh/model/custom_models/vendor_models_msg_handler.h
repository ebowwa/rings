#ifndef VENDOR_MODELS_MSG_HANDLER_H_
#define VENDOR_MODELS_MSG_HANDLER_H_


#include "tmall_model_msg_handler.h"



#endif
