#include "osapp_config.h"
#include "access_rx_process.h"
#include "generic_power_onoff_client.h"

void generic_power_onoff_status_rx(mesh_elmt_t *elmt,model_base_t *model,access_pdu_rx_t *pdu)
{
    LOG(3, "generic_power_onoff_status_rx\n");
}


