#ifndef GENERIC_BATTERY_COMMON__H
#define GENERIC_BATTERY_COMMON__H

enum GENERCI_BATTERY_FLAG_PRES
{
    BATTERY_NOT_PRE = 0x0,
    BATTERY_PRE_REMOVEABLE,
    BATTERY_PRE_NON_REMOVEABLE,
    BATTERY_PRE_UNKONW,
};


enum GENERCI_BATTERY_FLAG_IND
{
    BATTERY_CHARGE_CRI_LOW = 0x0,
    BATTERY_CHARGE_LOW,
    BATTERY_CHARGE_GOOD,
    BATTERY_CHARGE_UNKNOW,
};


enum GENERCI_BATTERY_FLAG_CHARG
{
    BATTERY_CHARGE_DISABLE = 0x0,
    BATTERY_CHARGE_NOT_CHARGING,
    BATTERY_CHARGE_CHARGING,
    BATTERY_CHARGE_STATE_UNKNOW,
};


enum GENERCI_BATTERY_FLAG_SERVICE
{
    RFU = 0x0,
    BATTER_NOT_REQ_SER,
    BATTER_REQ_SER,
    BATTERY_SER_UNKNOW
};


typedef struct
{
    uint8_t battey_level;
    uint8_t time_to_discharge[3];
    uint8_t time_to_charge[3];
    uint8_t flag;
}__attribute((packed))generic_msg_battery_status;
#endif


