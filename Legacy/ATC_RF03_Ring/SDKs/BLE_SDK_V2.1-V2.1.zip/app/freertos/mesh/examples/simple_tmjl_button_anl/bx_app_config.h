#ifndef BX_APP_CONFIG_H_
#define BX_APP_CONFIG_H_

#define DEEP_SLEEP_ENABLE 1     //disable sleep
#define ENABLE_ADV_PAYLOD_31BYTE_PATCH 1       //adv payload data max len 31byte
#define BX_DEV_NAME  "MESH_SWITCH"
//#define BX_DEV_ADDR {0x88,0x23,0x45,0x23,0x0F,0xC0}
#define MESH_SCHED_PATCH 1

//#define DEBUGGER_ATTACHED 0
#define SYSTICK_USED 0
#define RC32K_USED 0
#define DCDC_OFF 0
#define VBAT_MILLIVOLT 4200
#define configTICK_RATE_HZ 100

#define BLE_SOFT_WAKEUP_TIME 1000
#define BLE_WAKEUP_TIME 3000

#define RF_TX_POWER 0x1

#define SEGMENTED_PDU_RETRANSMIT_MAX_TIMES_UNICAST 2
#define SEGMENTED_PDU_RETRANSMIT_MAX_TIMES_VIRTUAL_GROUP 2
//这个是自定义的，会覆盖掉UUID
#define BX_DEV_ADDR {0xb9,0x9f,0x31,0xca,0xd2,0x38}
//#define BX_DEV_ADDR {0xdb,0x92,0x07,0x3a,0x9e,0x10}
//#define BX_DEV_ADDR {0xd5,0x86,0xf5,0x07,0xda,0x78}

#define MESH_PROVISION_SERVER_SUPPORT 1
#define MESH_PROVISION_CLIENT_SUPPORT 0

#endif
