/**
 ****************************************************************************************
 *
 * @file   mesh_app.c
 *
 * @brief  .
 *
 * @author  ZHAOYUNLIU
 * @date    2018-11-27 13:48
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "osapp_config.h"
#include <math.h>

#include "mesh_core_api.h"
#include "light_lightness_server.h"
#include "config_server_events_api.h"
#include "model_servers_events_api.h"
#include "config_server.h"
#include "mesh_node_base.h"
#include "generic_level_server.h"
#include "generic_onoff_server.h"
#include "mesh_app_hal.h"
#include "model_common.h"
#include "model_status_switch.h"
#include "node_setup.h"
#include "model_common.h"
#include "light_hsl_setup_server.h"
#include "light_ctl_server.h"
#include "light_ctl_setup_server.h"
#include "health_server.h"
#include "beacon.h"

/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */


#define APP_KEY_MAX 3
#define SUB_ADDR_MAX 4
mesh_addr_t sub_addr_list[SUB_ADDR_MAX];

///config server application
static light_hsl_msg_format_t hsl_msg_format;
static light_ctl_msg_format_t ctl_msg_format;
static light_lightness_msg_format_t lightness_msg_format[2];

DEF_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_0, APP_KEY_MAX);

DEF_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_0, APP_KEY_MAX);
DEF_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_1, APP_KEY_MAX);

DEF_HEALTH_SERVER_MODEL(health_server_0, APP_KEY_MAX);

DEF_LIGHT_LIGHTNESS_SERVER_MODEL(light_lightness_server_0, APP_KEY_MAX);

DEF_GENERIC_LEVEL_SERVER_MODEL(generic_level_server_0, APP_KEY_MAX);

DEF_LIGHT_HSL_SERVER_MODEL(light_hsl_server_0, APP_KEY_MAX);
DEF_LIGHT_HSL_SETUP_SERVER_MODEL(light_hsl_setup_server_0, APP_KEY_MAX);

DEF_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_1, APP_KEY_MAX);
DEF_HEALTH_SERVER_MODEL(health_server_1, APP_KEY_MAX);
DEF_GENERIC_LEVEL_SERVER_MODEL(generic_level_server_1, APP_KEY_MAX);
DEF_LIGHT_LIGHTNESS_SERVER_MODEL(light_lightness_server_1, APP_KEY_MAX);
DEF_LIGHT_CTL_SERVER_MODEL(light_ctl_server_1, APP_KEY_MAX);
DEF_LIGHT_CTL_SETUP_SERVER_MODEL(light_ctl_setup_server_1, APP_KEY_MAX);


void model_status_publish(void)
{
}

static void hsl_processing_and_state_bound(light_hsl_server_t *hsl_server)
{
    light_RGB light;

    LOG(LOG_LVL_INFO,"hsl_processing R:0x%x G:0x%x B:0x%x\n", \
            (uint16_t)(light.R), (uint16_t)(light.G), (uint16_t)(light.B));

    HSL2RGB(hsl_server->msg_format->present_hsl_hue/65535.0, 
            hsl_server->msg_format->present_hsl_saturation/65535.0,
            hsl_server->msg_format->present_hsl_lightness/65535.0,
            &light);

    hsl_server->state_bound->bound_cb(hsl_server->state_bound->led_r, (uint16_t)(light.R));
    hsl_server->state_bound->bound_cb(hsl_server->state_bound->led_g, (uint16_t)(light.G));
    hsl_server->state_bound->bound_cb(hsl_server->state_bound->led_b, (uint16_t)(light.B));
}

static void ctl_processing_and_state_bound(light_ctl_server_t *ctl_server)
{
    float temperature_warm;
    uint16_t lightness;

    temperature_warm = ((((float)ctl_server->msg_format->present_ctl_temperature) - T_MIN) * 0xffff) / (T_MAX - T_MIN);
    lightness = ctl_server->msg_format->present_ctl_lightness;

    LOG(3, "ctl_processing_and_state_bound:%x %x %x\n", ctl_server->msg_format->present_ctl_temperature, (uint16_t )(temperature_warm), lightness);
    if(lightness) {
        ctl_server->state_bound->bound_cb(ctl_server->state_bound->led_r, (uint16_t)temperature_warm);
        ctl_server->state_bound->bound_cb(ctl_server->state_bound->led_g, (uint16_t)lightness);
    }else {
        ctl_server->state_bound->bound_cb(ctl_server->state_bound->led_g, 0);
        ctl_server->state_bound->bound_cb(ctl_server->state_bound->led_r, 0);
    }
}

void user_onoff_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    switch(p_evt->type.onoff_type)
    {
        case ONOFF_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED1= %x %x!!!\n", generic_onoff_server_0.msg_format.present_onoff, p_evt->params.model_value_set.target_value);
            if(generic_onoff_server_0.msg_format.present_onoff != p_evt->params.model_value_set.target_value) {
                generic_onoff_server_0.msg_format.present_onoff = (uint8_t)p_evt->params.model_value_set.target_value;
                status_switch_onoff_to_level(&generic_onoff_server_0, &generic_level_server_0, light_lightness_server_0.msg_format->lightness_last);
                status_switch_onoff_to_lightness(&generic_onoff_server_0, &light_lightness_server_0);
                status_switch_onoff_to_hsl(&generic_onoff_server_0, &light_hsl_server_0, light_lightness_server_0.msg_format->lightness_last);
                hsl_processing_and_state_bound(&light_hsl_server_0);
            }
            break;
        case ONOFF_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"ONOFF_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}
void user_onoff_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    switch(p_evt->type.onoff_type)
    {
        case ONOFF_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED2=%d!!!\n",p_evt->params.model_value_set.target_value);
            if(generic_onoff_server_1.msg_format.present_onoff != p_evt->params.model_value_set.target_value) {
                generic_onoff_server_1.msg_format.present_onoff = (uint8_t)p_evt->params.model_value_set.target_value;
                status_switch_onoff_to_level(&generic_onoff_server_1, &generic_level_server_1, light_lightness_server_1.msg_format->lightness_last);
                status_switch_onoff_to_lightness(&generic_onoff_server_1, &light_lightness_server_1);
                status_switch_onoff_to_ctl(&generic_onoff_server_1, &light_ctl_server_1, light_lightness_server_1.msg_format->lightness_last);
                ctl_processing_and_state_bound(&light_ctl_server_1);
            }
            break;
        case ONOFF_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"ONOFF_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}
void user_level_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3,"user_level_0_evt_cb:%x\n", p_evt->type.level_type);
    switch(p_evt->type.level_type)
    {
        case LEVEL_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED1= %x %x!!!\n", generic_level_server_0.msg_format.present_level, p_evt->params.model_value_set.target_value);
            if(generic_level_server_0.msg_format.present_level != p_evt->params.model_value_set.target_value) {
                generic_level_server_0.msg_format.present_level = p_evt->params.model_value_set.target_value;
                status_switch_level_to_onoff(&generic_level_server_0, &generic_onoff_server_0);
                status_switch_level_to_lightness(&generic_level_server_0, &light_lightness_server_0);
                status_switch_level_to_hsl(&generic_level_server_0, &light_hsl_server_0);
                hsl_processing_and_state_bound(&light_hsl_server_0);
            }
            break;
        case LEVEL_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"LEVEL_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    } 
}
void user_level_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3,"user_level_1_evt_cb:%x\n", p_evt->type.level_type);
    switch(p_evt->type.level_type)
    {
        case LEVEL_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED2=%x!!!\n",p_evt->params.model_value_set.target_value);
            if(generic_level_server_1.msg_format.present_level != p_evt->params.model_value_set.target_value) {
                generic_level_server_1.msg_format.present_level = p_evt->params.model_value_set.target_value;
                status_switch_level_to_onoff(&generic_level_server_1, &generic_onoff_server_1);
                status_switch_level_to_lightness(&generic_level_server_1, &light_lightness_server_1);
                status_switch_level_to_ctl(&generic_level_server_1, &light_ctl_server_1);
                ctl_processing_and_state_bound(&light_ctl_server_1);
            }
            break;
        case LEVEL_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"LEVEL_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}

void user_lightness_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s type:%x\n", __func__, p_evt->type.lightness_type);
    uint16_t lightness = p_evt->params.model_value_set.target_value;
    switch(p_evt->type.lightness_type)
    {
        case LIGHTNESS_ACTUAL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED1=%x %x!!!\n", lightness, light_lightness_server_0.msg_format->present_lightness_actual);
            if(light_lightness_server_0.msg_format->present_lightness_actual != lightness) {
                light_lightness_server_0.msg_format->present_lightness_actual = lightness;
                light_lightness_server_0.msg_format->present_lightness_linear = (lightness * lightness)/65535;
                if(light_lightness_server_0.msg_format->present_lightness_actual)
                    light_lightness_server_0.msg_format->lightness_last = light_lightness_server_0.msg_format->present_lightness_actual;
                status_switch_lightness_to_onoff(&light_lightness_server_0, &generic_onoff_server_0);
                status_switch_lightness_to_level(&light_lightness_server_0, &generic_level_server_0);
                status_switch_lightness_to_hsl(&light_lightness_server_0, &light_hsl_server_0);
                hsl_processing_and_state_bound(&light_hsl_server_0);
            }
            break;
        case LIGHTNESS_ACTUAL_EVT_GET:
            LOG(LOG_LVL_INFO,"LIGHTNESS_ACTUAL_EVT_GET!!!\n");
            break;
        case LIGHTNESS_LINEAR_EVT_SET:
            if(light_lightness_server_0.msg_format->present_lightness_linear != lightness) {
                light_lightness_server_0.msg_format->present_lightness_linear = lightness;
                light_lightness_server_0.msg_format->present_lightness_actual = (uint16_t)sqrt(lightness * 65535);
                if(light_lightness_server_0.msg_format->present_lightness_actual)
                    light_lightness_server_0.msg_format->lightness_last = light_lightness_server_0.msg_format->present_lightness_actual;
                status_switch_lightness_to_onoff(&light_lightness_server_0, &generic_onoff_server_0);
                status_switch_lightness_to_level(&light_lightness_server_0, &generic_level_server_0);
                status_switch_lightness_to_hsl(&light_lightness_server_0, &light_hsl_server_0);
                hsl_processing_and_state_bound(&light_hsl_server_0);
            }
            break;
        case LIGHTNESS_LINEAR_EVT_GET:
            LOG(LOG_LVL_INFO,"LIGHTNESS_LINEAR_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}
void user_lightness_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s type:%x\n", __func__, p_evt->type.lightness_type);
    uint16_t lightness = p_evt->params.model_value_set.target_value;
    switch(p_evt->type.lightness_type)
    {
        case LIGHTNESS_ACTUAL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED2=%x %x!!!\n", lightness, light_lightness_server_0.msg_format->present_lightness_actual);
            if(light_lightness_server_1.msg_format->present_lightness_actual != lightness) {
                light_lightness_server_1.msg_format->present_lightness_actual = lightness;
                light_lightness_server_1.msg_format->present_lightness_linear = (lightness * lightness)/65535;
                if(light_lightness_server_1.msg_format->present_lightness_actual)
                    light_lightness_server_1.msg_format->lightness_last = light_lightness_server_1.msg_format->present_lightness_actual;
                status_switch_lightness_to_onoff(&light_lightness_server_1, &generic_onoff_server_1);
                status_switch_lightness_to_level(&light_lightness_server_1, &generic_level_server_1);
                status_switch_lightness_to_ctl(&light_lightness_server_1, &light_ctl_server_1);
                ctl_processing_and_state_bound(&light_ctl_server_1);
            }
            break;
        case LIGHTNESS_ACTUAL_EVT_GET:
            LOG(LOG_LVL_INFO,"LIGHTNESS_ACTUAL_EVT_GET!!!\n");
            break;
        case LIGHTNESS_LINEAR_EVT_SET:
            if(light_lightness_server_1.msg_format->present_lightness_linear != lightness) {
                light_lightness_server_1.msg_format->present_lightness_linear = lightness;
                light_lightness_server_1.msg_format->present_lightness_actual = (uint16_t)sqrt(lightness * 65535);
                if(light_lightness_server_1.msg_format->present_lightness_actual)
                    light_lightness_server_1.msg_format->lightness_last = light_lightness_server_1.msg_format->present_lightness_actual;
                status_switch_lightness_to_onoff(&light_lightness_server_1, &generic_onoff_server_1);
                status_switch_lightness_to_level(&light_lightness_server_1, &generic_level_server_1);
                status_switch_lightness_to_ctl(&light_lightness_server_1, &light_ctl_server_1);
                ctl_processing_and_state_bound(&light_ctl_server_1);
            }
            break;
        case LIGHTNESS_LINEAR_EVT_GET:
            LOG(LOG_LVL_INFO,"LIGHTNESS_LINEAR_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}

void user_hsl_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s type:%x\n", __func__, p_evt->type.hsl_type);
    uint16_t lightness = p_evt->params.model_hsl_set.target_hsl_lightness;
    uint16_t hue = p_evt->params.model_hsl_set.target_hsl_hue;
    uint16_t saturation = p_evt->params.model_hsl_set.target_hsl_saturation;
    switch(p_evt->type.hsl_type)
    {
        case LIGHT_HSL_SET:
                light_hsl_server_0.msg_format->present_hsl_lightness = lightness;
                light_hsl_server_0.msg_format->present_hsl_hue = hue;
                light_hsl_server_0.msg_format->present_hsl_saturation = saturation;

                status_switch_hsl_to_onoff(&light_hsl_server_0, &generic_onoff_server_0);
                status_switch_hsl_to_level(&light_hsl_server_0, &generic_level_server_0);
                status_switch_hsl_to_lightness(&light_hsl_server_0, &light_lightness_server_0);

                hsl_processing_and_state_bound(&light_hsl_server_0);
            break;
        case LIGHT_HSL_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_GET!!!\n");
            break;
        case LIGHT_HSL_HUE_SET:
            break;
        case LIGHT_HSL_HUE_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_HUE_GET!!!\n");
            break;
        case LIGHT_HSL_SATURATION_SET:
            break;
        case LIGHT_HSL_SATURATION_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_SATURATION_GET!!!\n");
            break;
        case LIGHT_HSL_DEFAULT_SET:
            break;
        case LIGHT_HSL_DEFAULT_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_DEFAULT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    } 
}

void user_hsl_setup_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s\n", __func__);
}

void user_ctl_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s type:%x\n", __func__, p_evt->type.ctl_type);
    uint16_t lightness = p_evt->params.model_ctl_set.target_ctl_lightness;
    uint16_t temperature = p_evt->params.model_ctl_set.target_ctl_temperature;
    uint16_t delta_uv = p_evt->params.model_ctl_set.target_ctl_delta_uv;
    switch(p_evt->type.ctl_type)
    {
        case LIGHT_CTL_SET:
            LOG(LOG_LVL_INFO,"!!!LED1=%x!!!\n", lightness);
                light_ctl_server_1.msg_format->present_ctl_lightness = lightness;
                if(temperature < T_MIN)
                    light_ctl_server_1.msg_format->present_ctl_temperature = T_MIN;
                else if(temperature > T_MAX)
                    light_ctl_server_1.msg_format->present_ctl_temperature = T_MAX;
                else
                    light_ctl_server_1.msg_format->present_ctl_temperature = temperature;
                light_ctl_server_1.msg_format->present_ctl_delta_uv = delta_uv;

                status_switch_ctl_to_onoff(&light_ctl_server_1, &generic_onoff_server_1);
                status_switch_ctl_to_level(&light_ctl_server_1, &generic_level_server_1);
                status_switch_ctl_to_lightness(&light_ctl_server_1, &light_lightness_server_1);
                ctl_processing_and_state_bound(&light_ctl_server_1);
            break;
        case LIGHT_CTL_GET:
            LOG(LOG_LVL_INFO,"LIGHT_CTL_GET!!!\n");
            break;
        case LIGHT_CTL_TEMPERATURE_SET:
            break;
        case LIGHT_CTL_TEMPERATURE_GET:
            LOG(LOG_LVL_INFO,"LIGHT_CTL_TEMPERATURE_GET!!!\n");
            break;
        case LIGHT_CTL_DEFAULT_SET:
            break;
        case LIGHT_CTL_DEFAULT_GET:
            LOG(LOG_LVL_INFO,"LIGHT_CTL_DEFAULT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}

void user_ctl_setup_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s\n", __func__);
}
void user_health_attention_0_evt_cb(const mesh_model_evt_t *p_evt)
{
    uint16_t attention_value = p_evt->params.model_value_set.target_value;
    LOG(3, "user_health_attention_0_evt_cb attention:%x\n", attention_value);
    if(attention_value) {

    }else {

    }
}
void user_health_attention_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    uint16_t attention_value = p_evt->params.model_value_set.target_value;
    LOG(3, "user_health_attention_1_evt_cb attention:%x\n", attention_value);
    if(attention_value) {

    }else {

    }
}

static void light_user_config_server_evt_cb(config_server_evt_type_t type, config_server_evt_param_t * p_param)
{
    //LOG(LOG_LVL_INFO , "light_user_config_server_evt_cb=%d\n",p_evt->type.level_type);
}



static void mesh_app_server_init(void)
{
    memset(&light_hsl_server_0, 0, sizeof(light_hsl_server_t));
    memset(&light_ctl_server_1, 0, sizeof(light_ctl_server_t));

    memset(&light_hsl_setup_server_0, 0, sizeof(light_hsl_setup_server_t));
    memset(&light_ctl_setup_server_1, 0, sizeof(light_ctl_setup_server_t));

    memset(&light_lightness_server_0, 0, sizeof(light_lightness_server_t));
    memset(&light_lightness_server_1, 0, sizeof(light_lightness_server_t));

    memset(&generic_transition_server_0, 0, sizeof(generic_transition_server_t));
    memset(&generic_transition_server_1, 0, sizeof(generic_transition_server_t));

    memset(&generic_level_server_0, 0, sizeof(generic_level_server_t));
    memset(&generic_level_server_1, 0, sizeof(generic_level_server_t));

    memset(&generic_onoff_server_0, 0, sizeof(generic_onoff_server_t));
    memset(&generic_onoff_server_1, 0, sizeof(generic_onoff_server_t));

    memset(&health_server_0, 0, sizeof(health_server_t));
    memset(&health_server_1, 0, sizeof(health_server_t));
    //1.init model
    INIT_LIGHT_HSL_SERVER_MODEL(light_hsl_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_hsl_0_evt_cb);
    INIT_LIGHT_CTL_SERVER_MODEL(light_ctl_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_ctl_1_evt_cb);

    INIT_LIGHT_HSL_SETUP_SERVER_MODEL(light_hsl_setup_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_hsl_setup_0_evt_cb);
    INIT_LIGHT_CTL_SETUP_SERVER_MODEL(light_ctl_setup_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_ctl_setup_1_evt_cb);

    INIT_LIGHT_LIGHTNESS_SERVER_MODEL(light_lightness_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_lightness_0_evt_cb);
    INIT_LIGHT_LIGHTNESS_SERVER_MODEL(light_lightness_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_lightness_1_evt_cb);

    INIT_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, NULL);
    INIT_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, NULL);

    INIT_GENERIC_LEVEL_SERVER_MODEL(generic_level_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_level_0_evt_cb);
    INIT_GENERIC_LEVEL_SERVER_MODEL(generic_level_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_level_1_evt_cb);

    INIT_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_onoff_0_evt_cb);
    INIT_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_onoff_1_evt_cb);

    INIT_HEALTH_SERVER_MODEL(health_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_health_attention_0_evt_cb);
    INIT_HEALTH_SERVER_MODEL(health_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_health_attention_1_evt_cb);

    //3.set initial state
    health_server_0.company_id = MESH_PARAM_CID;
    health_server_1.company_id = MESH_PARAM_CID;

    light_lightness_server_0.msg_format = &lightness_msg_format[0];
    light_hsl_server_0.msg_format = light_hsl_setup_server_0.msg_format = &hsl_msg_format;

    light_lightness_server_1.msg_format = &lightness_msg_format[1];
    light_ctl_server_1.msg_format = light_ctl_setup_server_1.msg_format = &ctl_msg_format;

    light_lightness_server_0.msg_format->lightness_range_max = 0xffff;
    light_lightness_server_0.msg_format->lightness_range_min = 0;

    light_lightness_server_1.msg_format->lightness_range_min = 0;
    light_lightness_server_1.msg_format->lightness_range_max = 0xffff;

    generic_onoff_server_0.msg_format.present_onoff = 1;

    generic_level_server_0.msg_format.present_level = 0;

    light_lightness_server_0.msg_format->present_lightness_actual = generic_level_server_0.msg_format.present_level + 32768;
    light_lightness_server_0.msg_format->present_lightness_linear = (light_lightness_server_0.msg_format->present_lightness_actual * light_lightness_server_0.msg_format->present_lightness_actual)/65535;
    light_lightness_server_0.msg_format->lightness_last = light_lightness_server_0.msg_format->present_lightness_actual;
    light_hsl_server_0.msg_format->present_hsl_lightness = light_lightness_server_0.msg_format->present_lightness_actual;
    light_hsl_server_0.msg_format->present_hsl_hue = 0;
    light_hsl_server_0.msg_format->present_hsl_saturation = 0;

    generic_level_server_1.msg_format.present_level = 0x8000;
    generic_onoff_server_1.msg_format.present_onoff = 0;

    light_lightness_server_1.msg_format->present_lightness_actual = generic_level_server_1.msg_format.present_level + 32768;
    light_lightness_server_1.msg_format->present_lightness_linear = (light_lightness_server_1.msg_format->present_lightness_actual * light_lightness_server_1.msg_format->present_lightness_actual)/65535;
    light_lightness_server_1.msg_format->lightness_last = light_lightness_server_1.msg_format->present_lightness_actual;
    light_ctl_server_1.msg_format->present_ctl_lightness = light_lightness_server_1.msg_format->present_lightness_actual;
    light_ctl_server_1.msg_format->present_ctl_temperature = T_MIN;
    light_ctl_server_1.msg_format->present_ctl_delta_uv = 0;

    model_common_state_bound_field_set(0, MODEL_STATE_BOUND_LIGHT_LIGHTNESS, hal_set_hsl_led);
    model_common_state_bound_leds_num_set(0, BX_DONGLE_LED1_R, BX_DONGLE_LED1_G, BX_DONGLE_LED1_B);
    generic_onoff_server_0.state_bound 
        = generic_level_server_0.state_bound 
        = light_lightness_server_0.state_bound 
        = light_hsl_server_0.state_bound 
        = model_common_state_bound_get_from_element_id(0);

    generic_onoff_server_0.delay_trans_timer
        = generic_level_server_0.delay_trans_timer
        = light_lightness_server_0.delay_trans_timer
        = light_hsl_server_0.delay_trans_timer
        = light_hsl_setup_server_0.delay_trans_timer
        = model_common_delay_trans_timer_get_from_element_id(0);

    model_common_state_bound_field_set(1, MODEL_STATE_BOUND_LIGHT_LIGHTNESS, hal_set_hsl_led);
    model_common_state_bound_leds_num_set(1, BX_DONGLE_LED2_R, BX_DONGLE_LED2_G, BX_DONGLE_LED2_B);

    generic_onoff_server_1.state_bound 
        = generic_level_server_1.state_bound 
        = light_lightness_server_1.state_bound 
        = light_ctl_server_1.state_bound 
        = model_common_state_bound_get_from_element_id(1);

    generic_onoff_server_1.delay_trans_timer
        = generic_level_server_1.delay_trans_timer
        = light_lightness_server_1.delay_trans_timer
        = light_ctl_server_1.delay_trans_timer
        = model_common_delay_trans_timer_get_from_element_id(1);

    LOG(3,"bound_type0:%x %p\n", generic_onoff_server_0.state_bound->bound_type, generic_level_server_0.state_bound);
    LOG(3,"bound_type1:%x %p\n", generic_onoff_server_1.state_bound->bound_type, generic_level_server_1.state_bound);

    LOG(3,"light_hsl_server_0:%p light_ctl_server_1:%p \n", &light_hsl_server_0, &light_ctl_server_1);
    LOG(3,"server_0_mode:%p server_1_mode:%p\n", &light_hsl_server_0.model, &light_ctl_server_1.model);
    LOG(3,"server->cb:%p server->cb:%p\n", light_hsl_server_0.cb, light_ctl_server_1.cb);
    //4.Register config server event callbacks
    regisite_config_server_evt_cb(light_user_config_server_evt_cb);

    beacon_start();
}

///end of config server application
void user_model_parameter_init(void)
{
    status_switch_hsl_to_onoff(&light_hsl_server_0, &generic_onoff_server_0);
    status_switch_hsl_to_level(&light_hsl_server_0, &generic_level_server_0);
    status_switch_hsl_to_lightness(&light_hsl_server_0, &light_lightness_server_0);
    hsl_processing_and_state_bound(&light_hsl_server_0);


    status_switch_ctl_to_onoff(&light_ctl_server_1, &generic_onoff_server_1);
    status_switch_ctl_to_level(&light_ctl_server_1, &generic_level_server_1);
    status_switch_ctl_to_lightness(&light_ctl_server_1, &light_lightness_server_1);
    ctl_processing_and_state_bound(&light_ctl_server_1);
}

//init user models
void mesh_node_setup(void)
{
    //system init node-element-model tree
    mesh_core_params_t param;
    param.role = MESH_ROLE_CONFIG_SERVER;
    mesh_core_params_set(MESH_CORE_PARAM_MESH_ROLES , &param);


    mesh_app_server_init();
}


