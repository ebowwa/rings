/**
 ****************************************************************************************
 *
 * @file   mesh_app.c
 *
 * @brief  .
 *
 * @author  liuzy
 * @date    2018-09-25 17:20
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "osapp_config.h"
//mesh platform
#include <math.h>
#include "mesh_errors.h"
#include "sdk_mesh_config.h"
#include "sdk_mesh_definitions.h"
#include "mesh_core_api.h"
//app
#include "node_setup.h"
#include "mesh_app_hal.h"
//tools
#include "co_utils.h"
#include <stdbool.h>
#include "string.h"
//feature
#include "node_save.h"
//model
#include "config_server_events_api.h"
#include "model_servers_events_api.h"
#include "config_server.h"
#include "generic_onoff_server.h"
#include "generic_transition_client.h"
#include "generic_power_onoff_server.h"
#include "generic_power_onoff_common.h"
#include "mesh_env.h"
#include "mesh_node_base.h"
#include "proxy_s.h"
#include "tmall_model_server.h"
#include "tmall_model_client.h"
#include "light_lightness_server.h"
#include "light_lightness_setup_server.h"
#include "light_lightness_client.h"
#include "light_ctl_client.h"
#include "light_ctl_common.h"
#include "light_ctl_setup_server.h"
#include "light_ctl_temperature_server.h"
#include "light_hsl_server.h"
#include "light_hsl_client.h"
#include "light_hsl_common.h"
#include "light_hsl_setup_server.h"
#include "light_hsl_hue_server.h"
#include "light_hsl_saturation_server.h"
#include "model_status_switch.h"
#include "generic_level_server.h"
#include "scheduler_server.h"
#include "scheduler_client.h"
#include "scene_server.h"
#include "scene_client.h"
#include "time_server.h"
#include "node_save_onpowerup.h"
#include "mesh_sched.h"
#include "beacon.h"
#include "access_tx_process.h"
#include "app_keys_dm.h"
#include "generic_onoff_client.h"
#include "generic_onoff_msg_handler.h"
#include "generic_onoff_common.h"
#include "tmall_model_common.h"

//hal
#include "mesh_app_hal.h"
#include "health_server.h"

#define ADV_CANCEL_TIMER_TIME_S 2
#define CLEAR_CURRENT_PRESS_TIMER_TIME_MS 500
#define APP_KEY_MAX 3
#define SUB_ADDR_MAX 4
mesh_addr_t sub_addr_list[SUB_ADDR_MAX];

extern int8_t send_pkt_type;
static uint8_t one_short_press_send_flag = 0;
static uint16_t last_server_value = 0;
static uint8_t current_state = BUTTON_SEND_PKT_STATUS;
static int8_t need_send_pkt_type = -1;
static int8_t last_send_pkt_type = 0;
static uint8_t recv_current_status = 0;

void model_status_publish(void)
{
}

static mesh_timer_t adv_cancel_timer;
static mesh_timer_t current_press_timer;

static light_lightness_msg_format_t lightness_msg_format;
static light_hsl_msg_format_t hsl_msg_format;
static light_ctl_msg_format_t ctl_msg_format;

DEF_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_0, APP_KEY_MAX);
DEF_HEALTH_SERVER_MODEL(health_server_0, APP_KEY_MAX);
DEF_GENERIC_LEVEL_SERVER_MODEL(generic_level_server_0, APP_KEY_MAX);
DEF_LIGHT_LIGHTNESS_SERVER_MODEL(light_lightness_server_0, APP_KEY_MAX);
DEF_LIGHT_HSL_SERVER_MODEL(light_hsl_server_0, APP_KEY_MAX);
DEF_LIGHT_CTL_SERVER_MODEL(light_ctl_server_0, APP_KEY_MAX);

DEF_TMALL_MODEL_SERVER_MODEL(tmall_model_server_0, APP_KEY_MAX);
DEF_TMALL_MODEL_CLIENT_MODEL(tmall_model_client_0, APP_KEY_MAX);

DEF_GENERIC_ONOFF_CLIENT_MODEL(generic_onoff_client_0, APP_KEY_MAX);
DEF_GENERIC_LEVEL_CLIENT_MODEL(generic_level_client_0, APP_KEY_MAX);
DEF_LIGHT_LIGHTNESS_CLIENT_MODEL(light_lightness_client_0, APP_KEY_MAX);
DEF_LIGHT_CTL_CLIENT_MODEL(light_ctl_client_0, APP_KEY_MAX);
DEF_LIGHT_HSL_CLIENT_MODEL(light_hsl_client_0, APP_KEY_MAX);

void set_recv_current_status(uint8_t status)
{
    recv_current_status = status;
}
uint8_t get_recv_current_status(void)
{
    return recv_current_status;
}

static uint8_t simple_light_tid(void)
{
    static uint8_t simple_light_tid=0;
    simple_light_tid++;
    return simple_light_tid;
}

void user_health_attention_0_evt_cb(const mesh_model_evt_t *p_evt)
{
    uint16_t attention_value = p_evt->params.model_value_set.target_value;
    LOG(3, "user_health_attention_0_evt_cb attention:%x\n", attention_value);
    if(attention_value) {

    }else {

    }
}

void user_call_tmall_attr_indication(void)
{
}

#define MAX_NUM(a, b) ((a) > (b) ? (a) : (b))
#define MIN_NUM(a, b) ((a) > (b) ? (b) : (a))

void user_button_clear_current_state(void)
{
    current_state = BUTTON_SEND_PKT_STATUS;
}

uint8_t user_button_get_current_state(void)
{
    return current_state;
}
uint8_t get_need_send_pkt_type(void)
{
    return need_send_pkt_type;
}
void clear_need_send_pkt_type(void)
{
    need_send_pkt_type = -1;
}

static void user_scan_stop_callback(void)
{
    LOG(3,"user_scan_stop_callback\n"); 
}

static void user_adv_cancel_timer_callback(mesh_timer_t xTimer)
{
    LOG(3, "user_adv_cancel_timer_callback\n");
    beacon_stop();
    mesh_sched_stop_scan(user_scan_stop_callback);
}
static void user_clear_current_press_status_callback(mesh_timer_t xTimer)
{
    LOG(3, "user_clear_current_press_status_callback\n");
    set_recv_current_status(0);
    last_send_pkt_type = 0;
    last_server_value = 0;
}

void user_level_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3,"user_level_0_evt_cb:%x\n", p_evt->type.level_type);
    switch(p_evt->type.level_type)
    {
        case LEVEL_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED1= %x %x!!!\n", generic_level_server_0.msg_format.present_level, p_evt->params.model_value_set.target_value);
            if(generic_onoff_server_0.msg_format.present_onoff == 0)
                return;
            if(generic_level_server_0.msg_format.present_level != p_evt->params.model_value_set.target_value) {
                generic_level_server_0.msg_format.present_level = p_evt->params.model_value_set.target_value;
                status_switch_level_to_onoff(&generic_level_server_0, &generic_onoff_server_0);
                status_switch_level_to_lightness(&generic_level_server_0, &light_lightness_server_0);
                status_switch_level_to_ctl(&generic_level_server_0, &light_ctl_server_0);
            }
            break;
        case LEVEL_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"LEVEL_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    } 
}

void user_button_set_current_value(uint8_t status, uint16_t value)
{
    LOG(3, "user_button_set_current_value: %x %x last:%x %x\n", 
            status, value, last_send_pkt_type, last_server_value);
    if(last_send_pkt_type == need_send_pkt_type && last_server_value == value)
        return;
    else {
        last_send_pkt_type = need_send_pkt_type;
        last_server_value = value;
    }

    set_recv_current_status(2);

    if(status == WAIT_FOR_GENERIC_ONOFF_STATUS) {
        generic_onoff_server_0.msg_format.present_onoff = (uint8_t)value ? 0 : 1;
    }else if(status == WAIT_FOR_LIGHT_LIGHTNESS_STATUS) {
        light_ctl_server_0.msg_format->present_ctl_lightness = value;
    }else if(status == WAIT_FOR_LIGHT_CTL_STATUS) {
        light_ctl_server_0.msg_format->present_ctl_temperature = value;
    }else if(status == WAIT_FOR_LIGHT_HSL_STATUS) {
        light_hsl_server_0.msg_format->present_hsl_lightness = value;
    }

    user_button_clear_current_state();

    LOG(3, "need_send_pkt_type:%x\n", need_send_pkt_type);
    if(need_send_pkt_type != 0) {
        switch(need_send_pkt_type) {
            case 1:
                user_adjust_light_lightness(0);
                break;
            case 2:
                user_adjust_light_lightness(1);
                break;
            case 3:
                user_adjust_light_onoff();
                break;
            case 4:
                user_adjust_stepless_lightness(0, ONE_STEP_OF_LIGHTNESS * 3);
                break;
            case 5:
                user_adjust_stepless_lightness(1, ONE_STEP_OF_LIGHTNESS * 3);
                break;
            case 6:
                user_adjust_stepless_temerature(0, ONE_STEP_OF_TEMERATURE * 3);
                break;
            case 7:
                user_adjust_stepless_temerature(1, ONE_STEP_OF_TEMERATURE * 3);
                break;
            case 8:
                user_adjust_light_to_warm();
                break;
            case 9:
                user_adjust_light_to_white();
                break;
            default:
                break;
        }
    }

    need_send_pkt_type = -1;
    beacon_stop();
    mesh_sched_stop_scan(user_scan_stop_callback);
}

static void send_get_current_status_msg_callback(void *pdu, uint8_t status)
{
    LOG(3, "send_get_current_status_msg_callback\n");
}
void send_get_current_status_msg(void)
{
    model_tx_msg_param_t tx_param;
    memset(&tx_param,0,sizeof(model_tx_msg_param_t));
    if(send_pkt_type == BUTTON_GET_GENERIC_ONOFF_STATUS) {
        tx_param.opcode = TWO_OCTETS_OPCODE_GEN(GENERIC_ONOFF_OPCODE_OFFSET, Generic_OnOff_Get);
        current_state = WAIT_FOR_GENERIC_ONOFF_STATUS;
    }else if(send_pkt_type == BUTTON_GET_LIGHT_LIGHTNESS_STATUS) {
        tx_param.opcode = TWO_OCTETS_OPCODE_GEN(LIGHT_LIGHTNESS_TWO_OCTETS_OPCODE_OFFSET, Light_Lightness_Get);
        current_state = WAIT_FOR_LIGHT_LIGHTNESS_STATUS;
    }else if(send_pkt_type == BUTTON_GET_LIGHT_CTL_STATUS) {
        tx_param.opcode = TWO_OCTETS_OPCODE_GEN(LIGHT_CTL_TWO_OCTETS_OPCODE_OFFSET, Light_CTL_Get);
        current_state = WAIT_FOR_LIGHT_CTL_STATUS;
    }else if(send_pkt_type == BUTTON_GET_LIGHT_HSL_STATUS) {
        tx_param.opcode = TWO_OCTETS_OPCODE_GEN(LIGHT_HSL_TWO_OCTETS_OPCODE_OFFSET, Light_HSL_Get);
        current_state = WAIT_FOR_LIGHT_HSL_STATUS;
    }
    LOG(3, "send_get_current_status_msg type:%x opcode:%x current_state:%x uni_addr:%x %x app_idex:%x\n",
            send_pkt_type, tx_param.opcode, current_state, light_ctl_client_0.model.base.elmt->uni_addr, light_lightness_client_0.model.base.elmt->uni_addr, light_ctl_client_0.model.base.publish->appkey_idx);
//
//    access_model_reply_test(&access_message_tx, light_ctl_client_0.model.base.elmt->uni_addr, 
//            0xc000, NULL, light_ctl_client_0.model.base.publish->appkey_idx);

    dm_appkey_index_to_appkey_handle(light_ctl_client_0.model.base.publish->appkey_idx ,&tx_param.key.app_key);
    tx_param.dst_addr.addr =0xc000;
    tx_param.pdu_length = 0;
    tx_param.seg = 1;
    tx_param.src_addr = light_ctl_client_0.model.base.elmt->uni_addr;
    tx_param.akf = 1;
    access_pdu_tx_t * ptr = access_model_pkt_build_fill(&tx_param,send_get_current_status_msg_callback, NULL);
    BX_ASSERT(ptr);
    access_send(ptr);
    one_short_press_send_flag = 0;

#if 1
    if(!mesh_timer_active(adv_cancel_timer)) {
        mesh_timer_start(adv_cancel_timer);
    }else {
        mesh_timer_change_period(adv_cancel_timer, pdS_TO_TICKS(ADV_CANCEL_TIMER_TIME_S));
    }
#endif
    if(!mesh_timer_active(current_press_timer)) {
        mesh_timer_start(current_press_timer);
    }else {
        mesh_timer_change_period(current_press_timer, pdMS_TO_TICKS(CLEAR_CURRENT_PRESS_TIMER_TIME_MS));
    }
}

void user_adjust_light_lightness(uint8_t light_flag)
{
    light_lightness_actual_set_t msg;
    uint32_t opcode = TWO_OCTETS_OPCODE_GEN(LIGHT_LIGHTNESS_TWO_OCTETS_OPCODE_OFFSET, Light_Lightness_Set_Unacknowledged);
    uint16_t lightness = 0;
    if(current_state >= WAIT_FOR_GENERIC_ONOFF_STATUS) {
        LOG(3, "%s:%d\n", __func__, __LINE__);
        if(light_flag)
            need_send_pkt_type = 2;
        else
            need_send_pkt_type = 1;
        return;
    }

    if(one_short_press_send_flag)
        return;
    one_short_press_send_flag = 1;

    if(light_flag) {
        lightness = light_ctl_server_0.msg_format->present_ctl_lightness;
        if(lightness >= 0xe661)
            lightness = 0xffff;
        else
            lightness += 0x1999;
    }else {
        lightness = light_ctl_server_0.msg_format->present_ctl_lightness;
        if(lightness <= 0x1999 + ONE_STEP_OF_LIGHTNESS)
            lightness = ONE_STEP_OF_LIGHTNESS;
        else
            lightness -= 0x1999;
    }

    LOG(3, "user_adjust_light_lightness lightness:%x addr:%x\n", lightness, light_ctl_server_0.model.base.subscription_list[0].addr.addr);

    msg.lightness_actual = lightness;
    msg.tid = simple_light_tid();
    msg.trans_time = 0x41;
    msg.delay = 0;

    light_hsl_server_0.msg_format->present_hsl_lightness = light_ctl_server_0.msg_format->present_ctl_lightness = msg.lightness_actual;

    light_lightness_msg_publish(&light_lightness_client_0, &msg, sizeof(light_lightness_actual_set_t), 0xc000, opcode);
}

void user_adjust_light_onoff(void)
{
    generic_onoff_msg_default_set_t msg;
    uint32_t opcode = TWO_OCTETS_OPCODE_GEN(GENERIC_ONOFF_OPCODE_OFFSET, Generic_OnOff_Set_Unacknowledged);
    if(current_state >= WAIT_FOR_GENERIC_ONOFF_STATUS) {
        LOG(3, "%s:%d\n", __func__, __LINE__);
        need_send_pkt_type = 3;
        return;
    }

    if(one_short_press_send_flag)
        return;
    one_short_press_send_flag = 1;

    //generic_onoff_server_0.msg_format.present_onoff = (generic_onoff_server_0.msg_format.present_onoff == 1) ? 0 : 1;

    LOG(3, "user_adjust_light_onoff onoff:%x\n", generic_onoff_server_0.msg_format.present_onoff);

    msg.onoff = generic_onoff_server_0.msg_format.present_onoff;
    msg.tid = simple_light_tid();

    generic_onoff_msg_publish(&generic_onoff_client_0, &msg, sizeof(generic_onoff_msg_default_set_t), 0xc000, opcode);
}

void user_adjust_stepless_lightness(uint8_t lightness_flag, uint16_t lightness_value)
{
    light_lightness_actual_default_t msg;
    uint32_t opcode = TWO_OCTETS_OPCODE_GEN(LIGHT_LIGHTNESS_TWO_OCTETS_OPCODE_OFFSET, Light_Lightness_Set_Unacknowledged);
    uint16_t lightness = 0;
    if(current_state >= WAIT_FOR_GENERIC_ONOFF_STATUS) {
        LOG(3, "%s:%d\n", __func__, __LINE__);
        if(lightness_flag)
            need_send_pkt_type = 5;
        else
            need_send_pkt_type = 4;
        return;
    }

    lightness = light_ctl_server_0.msg_format->present_ctl_lightness;

    if(lightness_flag) {
        if(0xffff - lightness_value <= lightness)
            lightness = 0xffff;
        else
            lightness += lightness_value;
    }else {
        if(lightness <= lightness_value + ONE_STEP_OF_LIGHTNESS)
            lightness = ONE_STEP_OF_LIGHTNESS;
        else {
            lightness -= lightness_value;
        }
    }

    LOG(3, "user_adjust_stepless_lightness lightness:%x addr:%x\n", lightness, light_ctl_server_0.model.base.subscription_list[0].addr.addr);

    msg.lightness_actual = lightness;
    msg.tid = simple_light_tid();

    light_hsl_server_0.msg_format->present_hsl_lightness = light_ctl_server_0.msg_format->present_ctl_lightness = msg.lightness_actual;

    light_lightness_msg_publish(&light_lightness_client_0, &msg, sizeof(light_lightness_actual_default_t), 0xc000, opcode);
}

void user_adjust_stepless_temerature(uint8_t temperature_flag, uint16_t temperature_value)
{
    light_ctl_set_default_t msg;
    uint32_t opcode = TWO_OCTETS_OPCODE_GEN(LIGHT_CTL_TWO_OCTETS_OPCODE_OFFSET, Light_CTL_Set_Unacknowledged);
    msg.ctl_lightness = light_ctl_server_0.msg_format->present_ctl_lightness;
    if(current_state >= WAIT_FOR_GENERIC_ONOFF_STATUS) {
        LOG(3, "%s:%d\n", __func__, __LINE__);
        if(temperature_flag)
            need_send_pkt_type = 7;
        else
            need_send_pkt_type = 6;
        return;
    }
    
    LOG(3, "user_adjust_stepless_temerature:%x\n", light_ctl_server_0.msg_format->present_ctl_temperature);
    if(temperature_flag) {
        if(T_MAX - temperature_value <= light_ctl_server_0.msg_format->present_ctl_temperature)
            light_ctl_server_0.msg_format->present_ctl_temperature = msg.ctl_temperature = T_MAX;
        else
            msg.ctl_temperature = light_ctl_server_0.msg_format->present_ctl_temperature = light_ctl_server_0.msg_format->present_ctl_temperature + temperature_value;
    }else {
        if(temperature_value >= light_ctl_server_0.msg_format->present_ctl_temperature)
            light_ctl_server_0.msg_format->present_ctl_temperature = msg.ctl_temperature = T_MIN;
        else
            msg.ctl_temperature = light_ctl_server_0.msg_format->present_ctl_temperature = light_ctl_server_0.msg_format->present_ctl_temperature - temperature_value;
    }

    msg.ctl_delta_uv = 0;
    msg.tid = simple_light_tid();
    
    light_ctl_msg_publish(&light_ctl_client_0, &msg, sizeof(light_ctl_set_default_t), 0xc000, opcode);
}


void user_adjust_to_neutral_light(void)
{
    static uint8_t state = 0;
    light_ctl_set_t msg;
    uint32_t opcode = TWO_OCTETS_OPCODE_GEN(LIGHT_CTL_TWO_OCTETS_OPCODE_OFFSET, Light_CTL_Set_Unacknowledged);
    uint16_t temperature;

    state %= 3;


    if(state == 0)
        temperature = (T_MAX + T_MIN)/2;
    else if(state == 1)
        temperature = T_MAX;
    else
        temperature = T_MIN;

    state++;

    msg.ctl_lightness = light_ctl_server_0.msg_format->present_ctl_lightness;
    msg.ctl_temperature = temperature;
    msg.ctl_delta_uv = 0;
    msg.tid = simple_light_tid();
    msg.trans_time = 0x41;
    msg.delay = 0;

    light_ctl_server_0.msg_format->present_ctl_lightness = msg.ctl_lightness;
    light_ctl_server_0.msg_format->present_ctl_temperature = msg.ctl_temperature;

    light_ctl_msg_publish(&light_ctl_client_0, &msg, sizeof(light_ctl_set_t), 0xc000, opcode);

    mesh_sched_stop_scan(user_scan_stop_callback);
}

void user_adjust_light_to_warm(void)
{
    light_ctl_set_t msg;
    uint32_t opcode = TWO_OCTETS_OPCODE_GEN(LIGHT_CTL_TWO_OCTETS_OPCODE_OFFSET, Light_CTL_Set_Unacknowledged);
    msg.ctl_lightness = light_ctl_server_0.msg_format->present_ctl_lightness;
    if(current_state >= WAIT_FOR_GENERIC_ONOFF_STATUS) {
        LOG(3, "%s:%d\n", __func__, __LINE__);
        need_send_pkt_type = 8;
        return;
    }

    if(one_short_press_send_flag)
        return;
    one_short_press_send_flag = 1;
    
    if(light_ctl_server_0.msg_format->present_ctl_temperature <= T_MIN + ONE_STEP_OF_TEMERATURE * 10)
        light_ctl_server_0.msg_format->present_ctl_temperature = msg.ctl_temperature = T_MIN;
    else
        msg.ctl_temperature = light_ctl_server_0.msg_format->present_ctl_temperature = light_ctl_server_0.msg_format->present_ctl_temperature - ONE_STEP_OF_TEMERATURE * 10;

    msg.ctl_delta_uv = 0;
    msg.tid = simple_light_tid();
    msg.trans_time = 0x41;
    msg.delay = 0;
    LOG(3, "user_adjust_light_to_warm:%x tid:%x\n", \
            light_ctl_server_0.msg_format->present_ctl_temperature, msg.tid);
    
    light_ctl_msg_publish(&light_ctl_client_0, &msg, sizeof(light_ctl_set_t), 0xc000, opcode);
}

void user_adjust_light_to_white(void)
{
    light_ctl_set_t msg;
    uint32_t opcode = TWO_OCTETS_OPCODE_GEN(LIGHT_CTL_TWO_OCTETS_OPCODE_OFFSET, Light_CTL_Set_Unacknowledged);

    if(current_state >= WAIT_FOR_GENERIC_ONOFF_STATUS) {
        LOG(3, "%s:%d\n", __func__, __LINE__);
        need_send_pkt_type = 9;
        return;
    }
    if(one_short_press_send_flag)
        return;
    one_short_press_send_flag = 1;

    msg.ctl_lightness = light_ctl_server_0.msg_format->present_ctl_lightness;
    if(light_ctl_server_0.msg_format->present_ctl_temperature >= T_MAX - ONE_STEP_OF_TEMERATURE * 10)
        light_ctl_server_0.msg_format->present_ctl_temperature = msg.ctl_temperature = T_MAX;
    else
        msg.ctl_temperature = light_ctl_server_0.msg_format->present_ctl_temperature = light_ctl_server_0.msg_format->present_ctl_temperature + ONE_STEP_OF_TEMERATURE * 10;
    
    msg.ctl_delta_uv = 0;
    msg.tid = simple_light_tid();
    msg.trans_time = 0x41;
    msg.delay = 0;

    LOG(3, "user_adjust_light_to_white:%x tid:%x\n", \
            light_ctl_server_0.msg_format->present_ctl_temperature, msg.tid);

    light_ctl_msg_publish(&light_ctl_client_0, &msg, sizeof(light_ctl_set_t), 0xc000, opcode);
}

void user_tmall_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "user_tmall_0_evt_cb:%x %x %x %x\n", 
            tmall_model_server_0.msg_format[0].attr_type, tmall_model_server_0.msg_format[0].value[0], tmall_model_server_0.msg_format[0].value[1], tmall_model_server_0.msg_format[0].value[2]);
    if(tmall_model_server_0.msg_format[0].attr_type == 0x0123) {
        light_hsl_server_0.msg_format->target_hsl_lightness = light_hsl_server_0.msg_format->present_hsl_lightness = tmall_model_server_0.msg_format[0].value[0];
        light_hsl_server_0.msg_format->target_hsl_hue = light_hsl_server_0.msg_format->present_hsl_hue = tmall_model_server_0.msg_format[0].value[1];
        light_hsl_server_0.msg_format->target_hsl_saturation = light_hsl_server_0.msg_format->present_hsl_saturation = tmall_model_server_0.msg_format[0].value[2];

        status_switch_hsl_to_onoff(&light_hsl_server_0, &generic_onoff_server_0);
    }
}

void user_onoff_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "user_onoff_0_evt_cb:%d\n", p_evt->params.model_value_set.target_value);
    generic_onoff_server_0.msg_format.present_onoff = p_evt->params.model_value_set.target_value;
}

void user_lightness_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    uint16_t lightness = p_evt->params.model_value_set.target_value;
    LOG(3, "%s type:%x\n", __func__, p_evt->type.lightness_type);
    switch(p_evt->type.lightness_type)
    {
        case LIGHTNESS_ACTUAL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LIGHTNESS_ACTUAL_EVT_SET:%x %x!!!\n", lightness, light_lightness_server_0.msg_format->present_lightness_actual);
                light_lightness_server_0.msg_format->present_lightness_actual = lightness;
                light_lightness_server_0.msg_format->present_lightness_linear = (lightness * lightness)/65535;
                if(light_lightness_server_0.msg_format->present_lightness_actual)
                    light_lightness_server_0.msg_format->lightness_last = light_lightness_server_0.msg_format->present_lightness_actual;
                status_switch_lightness_to_onoff(&light_lightness_server_0, &generic_onoff_server_0);
                status_switch_lightness_to_hsl(&light_lightness_server_0, &light_hsl_server_0);
                status_switch_lightness_to_ctl(&light_lightness_server_0, &light_ctl_server_0);
            break;
        default:
            break;
    }
}

void user_ctl_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s type:%x\n", __func__, p_evt->type.ctl_type);
    uint16_t lightness = p_evt->params.model_ctl_set.target_ctl_lightness;
    uint16_t temperature = p_evt->params.model_ctl_set.target_ctl_temperature;
    uint16_t delta_uv = p_evt->params.model_ctl_set.target_ctl_delta_uv;
    switch(p_evt->type.ctl_type)
    {
        case LIGHT_CTL_SET:
                LOG(LOG_LVL_INFO,"!!!LIGHT_CTL_SET:%x %x!!!\n", lightness, light_ctl_server_0.msg_format->present_ctl_lightness);
                //light_ctl_server_0.msg_format->present_ctl_lightness = lightness;
                if(temperature < T_MIN)
                    light_ctl_server_0.msg_format->present_ctl_temperature = T_MIN;
                else if(temperature > T_MAX)
                    light_ctl_server_0.msg_format->present_ctl_temperature = T_MAX;
                else
                    light_ctl_server_0.msg_format->present_ctl_temperature = temperature;

                light_ctl_server_0.msg_format->present_ctl_delta_uv = delta_uv;

                //status_switch_ctl_to_onoff(&light_ctl_server_0, &generic_onoff_server_0);
                break;
            default:
                break;
    }
}

void user_hsl_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    uint16_t lightness = p_evt->params.model_hsl_set.target_hsl_lightness;
    uint16_t hue = p_evt->params.model_hsl_set.target_hsl_hue;
    uint16_t saturation = p_evt->params.model_hsl_set.target_hsl_saturation;
    LOG(3, "%s type:%x value:%x %x %x\n", __func__, p_evt->type.hsl_type, lightness, hue, saturation);
    switch(p_evt->type.hsl_type)
    {
        case LIGHT_HSL_SET:
                LOG(LOG_LVL_INFO,"LIGHT_HSL_SET!!!\n");
                light_hsl_server_0.msg_format->present_hsl_lightness = lightness;
                light_hsl_server_0.msg_format->present_hsl_hue = hue;
                light_hsl_server_0.msg_format->present_hsl_saturation = saturation;
            break;
        default:
            break;
    }
}

void user_config_server_evt_cb(config_server_evt_type_t type, config_server_evt_param_t*p_param)
{
    LOG(LOG_LVL_INFO , "user_config_server_evt_cb=%d\n",type);

    switch(type)
    {
        case CONFIG_SERVER_EVT_RELAY_SET :
        {
        }
        case CONFIG_SERVER_EVT_APPKEY_ADD:
        {
            uint8_t status = 0;
            bind_appkey_to_model(&tmall_model_server_0.model.base, 0, &status);
            bind_appkey_to_model(&tmall_model_client_0.model.base, 0, &status);
            bind_appkey_to_model(&health_server_0.model.base, 0, &status);
            bind_appkey_to_model(&generic_onoff_client_0.model.base, 0, &status);
            bind_appkey_to_model(&generic_level_client_0.model.base, 0, &status);
            bind_appkey_to_model(&light_lightness_client_0.model.base, 0, &status);
            bind_appkey_to_model(&light_ctl_client_0.model.base, 0, &status);
            bind_appkey_to_model(&light_hsl_client_0.model.base, 0, &status);

            bind_appkey_to_model(&generic_onoff_server_0.model.base, 0, &status);
            bind_appkey_to_model(&light_lightness_server_0.model.base, 0, &status);
            bind_appkey_to_model(&light_ctl_server_0.model.base, 0, &status);
            bind_appkey_to_model(&light_hsl_server_0.model.base, 0, &status);
        }
        break;
        case CONFIG_SERVER_EVT_MODEL_SUBSCRIPTION_ADD:
        {
#if 0
            LOG(LOG_LVL_INFO , "user_config_server_evt_cb addr:%x\n", p_param->model_subscription_add.address);
            config_model_subscription_add(tmall_model_server_0.model.base.elmt, &tmall_model_server_0.model.base, 0xc000);
            config_model_subscription_add(tmall_model_client_0.model.base.elmt, &tmall_model_client_0.model.base, 0xc000);
            config_model_subscription_add(generic_onoff_client_0.model.base.elmt, &generic_onoff_client_0.model.base, 0xc000);
            config_model_subscription_add(generic_level_client_0.model.base.elmt, &generic_level_client_0.model.base, 0xc000);
            config_model_subscription_add(light_lightness_client_0.model.base.elmt, &light_lightness_client_0.model.base, 0xc000);
            config_model_subscription_add(light_ctl_client_0.model.base.elmt, &light_ctl_client_0.model.base, 0xc000);
            config_model_subscription_add(light_hsl_client_0.model.base.elmt, &light_hsl_client_0.model.base, 0xc000);

            config_model_subscription_add(generic_onoff_server_0.model.base.elmt, &generic_onoff_server_0.model.base, 0xc000);
            config_model_subscription_add(light_lightness_server_0.model.base.elmt, &light_lightness_server_0.model.base, 0xc000);
            config_model_subscription_add(light_ctl_server_0.model.base.elmt, &light_ctl_server_0.model.base, 0xc000);
            config_model_subscription_add(light_hsl_server_0.model.base.elmt, &light_hsl_server_0.model.base, 0xc000);
#endif
#if 0
            config_model_subscription_add(tmall_model_server_0.model.base.elmt, &tmall_model_server_0.model.base, p_param->model_subscription_add.address);
            config_model_subscription_add(tmall_model_client_0.model.base.elmt, &tmall_model_client_0.model.base, p_param->model_subscription_add.address);
            config_model_subscription_add(generic_onoff_client_0.model.base.elmt, &generic_onoff_client_0.model.base, p_param->model_subscription_add.address);
            config_model_subscription_add(generic_level_client_0.model.base.elmt, &generic_level_client_0.model.base, p_param->model_subscription_add.address);
            config_model_subscription_add(light_lightness_client_0.model.base.elmt, &light_lightness_client_0.model.base, p_param->model_subscription_add.address);
            config_model_subscription_add(light_ctl_client_0.model.base.elmt, &light_ctl_client_0.model.base, p_param->model_subscription_add.address);
            config_model_subscription_add(light_hsl_client_0.model.base.elmt, &light_hsl_client_0.model.base, p_param->model_subscription_add.address);

            config_model_subscription_add(generic_onoff_server_0.model.base.elmt, &generic_onoff_server_0.model.base, p_param->model_subscription_add.address);
            config_model_subscription_add(light_lightness_server_0.model.base.elmt, &light_lightness_server_0.model.base, p_param->model_subscription_add.address);
            config_model_subscription_add(light_ctl_server_0.model.base.elmt, &light_ctl_server_0.model.base, p_param->model_subscription_add.address);
            config_model_subscription_add(light_hsl_server_0.model.base.elmt, &light_hsl_server_0.model.base, p_param->model_subscription_add.address);
#endif
#if 1
            if(!mesh_timer_active(adv_cancel_timer)) {
                mesh_timer_start(adv_cancel_timer);
            }else {
                mesh_timer_change_period(adv_cancel_timer, pdS_TO_TICKS(ADV_CANCEL_TIMER_TIME_S));
            }
#endif
            break;
        }
        default:break;
    }
}

void mesh_app_client_init(void)
{
    memset(&health_server_0, 0, sizeof(health_server_t));
    memset(&generic_onoff_server_0, 0, sizeof(generic_onoff_server_t)); 
    memset(&light_ctl_server_0, 0, sizeof(light_ctl_server_t));
    memset(&light_lightness_server_0, 0, sizeof(light_lightness_server_t));
    memset(&health_server_0, 0, sizeof(health_server_t));
    memset(&light_hsl_server_0, 0, sizeof(light_hsl_server_t));
    memset(&generic_onoff_client_0, 0, sizeof(generic_onoff_client_t));
    memset(&generic_level_client_0, 0, sizeof(generic_onoff_client_t));
    memset(&light_lightness_client_0, 0, sizeof(generic_onoff_client_t));
    memset(&light_ctl_client_0, 0, sizeof(generic_onoff_client_t));
    memset(&light_hsl_client_0, 0, sizeof(generic_onoff_client_t));

    //1.init model
    INIT_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_onoff_0_evt_cb);
    INIT_GENERIC_LEVEL_SERVER_MODEL(generic_level_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_level_0_evt_cb);
    INIT_LIGHT_LIGHTNESS_SERVER_MODEL(light_lightness_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_lightness_0_evt_cb);
    INIT_LIGHT_CTL_SERVER_MODEL(light_ctl_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_ctl_0_evt_cb);
    INIT_LIGHT_HSL_SERVER_MODEL(light_hsl_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_hsl_0_evt_cb);

    INIT_HEALTH_SERVER_MODEL(health_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_health_attention_0_evt_cb);
    INIT_CUSTOM_TMALL_SERVER_MODEL(tmall_model_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_tmall_0_evt_cb);
    INIT_CUSTOM_TMALL_CLIENT_MODEL(tmall_model_client_0, APP_KEY_MAX, 0, NULL, 0);

    INIT_GENERIC_ONOFF_CLIENT_MODEL(generic_onoff_client_0, APP_KEY_MAX, 0, NULL, 0);
    INIT_GENERIC_LEVEL_CLIENT_MODEL(generic_level_client_0, APP_KEY_MAX, 0, NULL, 0);
    INIT_LIGHT_CTL_CLIENT_MODEL(light_ctl_client_0, APP_KEY_MAX, 0, NULL, 0);
    INIT_LIGHT_HSL_CLIENT_MODEL(light_hsl_client_0, APP_KEY_MAX, 0, NULL, 0);
    INIT_LIGHT_LIGHTNESS_CLIENT_MODEL(light_lightness_client_0, APP_KEY_MAX, 0, NULL, 0);

    //3.set initial state
    light_hsl_server_0.msg_format = &hsl_msg_format;
    light_ctl_server_0.msg_format = &ctl_msg_format;
    light_lightness_server_0.msg_format = &lightness_msg_format;

    generic_onoff_server_0.msg_format.present_onoff = 1;
    health_server_0.company_id = MESH_PARAM_CID;

    light_ctl_server_0.msg_format->present_ctl_lightness = light_hsl_server_0.msg_format->present_hsl_lightness = 0xffff;
    light_ctl_server_0.msg_format->present_ctl_temperature = (T_MAX+T_MIN)/2;
    light_ctl_server_0.msg_format->present_ctl_delta_uv = 0;
    light_ctl_server_0.msg_format->range_min = T_MIN;
    light_ctl_server_0.msg_format->range_max = T_MAX;
    light_lightness_server_0.msg_format->lightness_range_min = 0x0;
    light_lightness_server_0.msg_format->lightness_range_max = 0xffff;
    light_hsl_server_0.msg_format->hue_range_min = 0;
    light_hsl_server_0.msg_format->hue_range_max = 0xffff;
    light_hsl_server_0.msg_format->saturation_range_min = 0;
    light_hsl_server_0.msg_format->saturation_range_max = 0xffff;

    tmall_model_client_0.set_current_value_cb 
        = generic_onoff_client_0.set_current_value_cb 
        = generic_level_client_0.set_current_value_cb 
        = light_lightness_client_0.set_current_value_cb 
        = light_ctl_client_0.set_current_value_cb 
        = light_hsl_client_0.set_current_value_cb 
        = user_button_set_current_value;

    tmall_model_client_0.get_current_state_cb
        = generic_onoff_client_0.get_current_state_cb
        = generic_level_client_0.get_current_state_cb
        = light_lightness_client_0.get_current_state_cb
        = light_ctl_client_0.get_current_state_cb
        = light_hsl_client_0.get_current_state_cb
        = user_button_get_current_state;

    generic_onoff_server_0.state_bound 
        = light_lightness_server_0.state_bound 
        = light_hsl_server_0.state_bound 
        = model_common_state_bound_get_from_element_id(0);

    generic_onoff_server_0.delay_trans_timer 
        = light_lightness_server_0.delay_trans_timer
        = light_hsl_server_0.delay_trans_timer
        = model_common_delay_trans_timer_get_from_element_id(0);

    light_ctl_server_0.state_bound = model_common_state_bound_get_from_element_id(1);
    light_ctl_server_0.delay_trans_timer = model_common_delay_trans_timer_get_from_element_id(1);

     adv_cancel_timer = mesh_timer_create("adv_cancel_timer", \
             pdS_TO_TICKS(ADV_CANCEL_TIMER_TIME_S), pdFALSE, adv_cancel_timer, user_adv_cancel_timer_callback);

     current_press_timer = mesh_timer_create("current_press_timer", \
             pdMS_TO_TICKS(CLEAR_CURRENT_PRESS_TIMER_TIME_MS), pdFALSE, current_press_timer, user_clear_current_press_status_callback);

    //4.Register config server event callbacks
    regisite_config_server_evt_cb(user_config_server_evt_cb);
}

void user_model_parameter_init(void)
{
    uint8_t onoffcount = node_recover_system_onoffcount();

    set_tmall_server(&tmall_model_server_0);

    if(onoffcount == 0xf0) {
        node_save_system_onoffcount(0);
        node_save_write_through();
        user_onoff_timer_init();
        beacon_start();
        mesh_sched_start_scan();
    }else {
        beacon_stop();
        mesh_sched_stop_scan(user_scan_stop_callback);
    }
}

//init user models
void mesh_node_setup(void)
{
    //system init node-element-model tree
    mesh_core_params_t param;
    param.role = MESH_ROLE_CONFIG_SERVER;
    mesh_core_params_set(MESH_CORE_PARAM_MESH_ROLES , &param);
    //init user model list
    mesh_app_client_init();
}

