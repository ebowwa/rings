/**
 ****************************************************************************************
 *
 * @file   simple_time_scheduler_s.h
 *
 * @brief  .
 *
 * @author  liuzy
 * @date    2018-09-25 16:17
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup MESH_simple_time_scheduler_s_API Mesh simple_time_scheduler_s API
 * @ingroup MESH_API
 * @brief Mesh simple_time_scheduler_s  API
 *
 * @{
 ****************************************************************************************
 */

#ifndef FREERTOS_APP_MESH_EXAMPLES_SIMPLE_TIME_SCHEDULER_SERVER_SIMPLE_TIME_SCHEDULER_S_H_
#define FREERTOS_APP_MESH_EXAMPLES_SIMPLE_TIME_SCHEDULER_SERVER_SIMPLE_TIME_SCHEDULER_S_H_

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "mesh_errors.h"
#include "sdk_mesh_config.h"
#include "sdk_mesh_definitions.h"

/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */


/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
void simple_time_scheduler_server_init(void);


#endif /* FREERTOS_APP_MESH_EXAMPLES_SIMPLE_TIME_SCHEDULER_SERVER_SIMPLE_TIME_SCHEDULER_S_H_ */ 
/// @} MESH_simple_time_scheduler_s_API

