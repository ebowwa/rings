/**
 ****************************************************************************************
 *
 * @file   low_power_test.c
 *
 * @brief  .
 *
 * @author  jiachuang
 * @date    2019-07-25 15:25
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) BlueX Microelectronics 2019
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "osapp_config.h"


#include "mesh_queued_msg.h"
#include "friend_test.h"
#include "mesh_kr_comm.h"
#include "mesh_kr_server.h"
/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */




/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/*
 * LOCAL FUNCTIONS DEFINITIONS
 ****************************************************************************************
 */

void button_action(uint8_t button_idx)
{
//    set_lp_default_netkey_global_idx();
//    mesh_queued_msg_send((void*)friend_request_tx , NULL);
extern  err_t mesh_kr_config_netkey_phase(mesh_global_idx_t netkey_index, mesh_key_refresh_transition_t  transiton);

    if(3 == button_idx)
    {
        mesh_kr_config_netkey_phase(0,MESH_KEY_TRANSITION_TO_PHASE_2);
    } else if(4 == button_idx)
    {
        mesh_kr_config_netkey_phase(0,MESH_KEY_TRANSITION_TO_PHASE_3);
    }
}


