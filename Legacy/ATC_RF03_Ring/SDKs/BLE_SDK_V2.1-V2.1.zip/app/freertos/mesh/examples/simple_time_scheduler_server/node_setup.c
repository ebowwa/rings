/**
 ****************************************************************************************
 *
 * @file   mesh_app.c
 *
 * @brief  .
 *
 * @author  liuzy
 * @date    2018-09-25 17:20
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "osapp_config.h"
//mesh platform
#include "mesh_errors.h"
#include "sdk_mesh_config.h"
#include "sdk_mesh_definitions.h"
//app
#include "node_setup.h"
#include "mesh_app_hal.h"
#include "mesh_core_api.h"
//tools
#include "co_utils.h"
#include <stdbool.h>
#include "string.h"
//feature
#include "node_save.h"
//model
#include "config_server_events_api.h"
#include "model_servers_events_api.h"
#include "config_server.h"
#include "scene_server.h"
#include "time_server.h"
#include "mesh_env.h"
#include "mesh_node_base.h"
#include "proxy_s.h"
#include "node_save_scene.h"
#include "bxfs.h"
#include "light_lightness_server.h"
#include "config_server_events_api.h"
#include "model_servers_events_api.h"
#include "config_server.h"
#include "mesh_node_base.h"
#include "generic_level_server.h"
#include "generic_onoff_server.h"
#include "mesh_app_hal.h"
#include "model_common.h"
#include "model_status_switch.h"
#include "math.h"
#include "scheduler_server.h"
#include "node_save_scheduler.h"
#include "generic_transition_server.h"
#include "health_server.h"
#include "beacon.h"
#include "light_hsl_setup_server.h"

/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

#define APP_KEY_MAX 3
#define SUB_ADDR_MAX 4
mesh_addr_t sub_addr_list[SUB_ADDR_MAX];

///config server application
DEF_SCHEDULER_SERVER_MODEL(scheduler_server_0, APP_KEY_MAX);
DEF_SCHEDULER_SERVER_MODEL(scheduler_server_1, APP_KEY_MAX);
DEF_SCHEDULER_SETUP_SERVER_MODEL(scheduler_setup_server_0, APP_KEY_MAX);
DEF_SCHEDULER_SETUP_SERVER_MODEL(scheduler_setup_server_1, APP_KEY_MAX);

DEF_SCENE_SERVER_MODEL(scene_server_0, APP_KEY_MAX);
DEF_SCENE_SERVER_MODEL(scene_server_1, APP_KEY_MAX);
DEF_SCENE_SETUP_SERVER_MODEL(scene_setup_server_0, APP_KEY_MAX);
DEF_SCENE_SETUP_SERVER_MODEL(scene_setup_server_1, APP_KEY_MAX);

DEF_TIME_SERVER_MODEL(time_server_0, APP_KEY_MAX);
DEF_TIME_SERVER_MODEL(time_server_1, APP_KEY_MAX);
DEF_TIME_SETUP_SERVER_MODEL(time_setup_server_0, APP_KEY_MAX);
DEF_TIME_SETUP_SERVER_MODEL(time_setup_server_1, APP_KEY_MAX);

static time_server_msg_format_t time_msg[ELEMENT_NUM];
static scene_server_msg_format_t scene_msg[ELEMENT_NUM];
static scheduler_server_msg_format_t scheduler_msg[ELEMENT_NUM];
static scheduler_time_param_t scheduler_time_msg[ELEMENT_NUM];
static light_hsl_msg_format_t hsl_msg_format[ELEMENT_NUM];
static light_lightness_msg_format_t lightness_msg_format[ELEMENT_NUM];

DEF_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_0, APP_KEY_MAX);
DEF_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_1, APP_KEY_MAX);

DEF_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_0, APP_KEY_MAX);
DEF_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_1, APP_KEY_MAX);

DEF_HEALTH_SERVER_MODEL(health_server_0, APP_KEY_MAX);
DEF_HEALTH_SERVER_MODEL(health_server_1, APP_KEY_MAX);

DEF_LIGHT_LIGHTNESS_SERVER_MODEL(light_lightness_server_0, APP_KEY_MAX);
DEF_LIGHT_LIGHTNESS_SERVER_MODEL(light_lightness_server_1, APP_KEY_MAX);

DEF_GENERIC_LEVEL_SERVER_MODEL(generic_level_server_0, APP_KEY_MAX);
DEF_GENERIC_LEVEL_SERVER_MODEL(generic_level_server_1, APP_KEY_MAX);

DEF_LIGHT_HSL_SERVER_MODEL(light_hsl_server_0, APP_KEY_MAX);
DEF_LIGHT_HSL_SERVER_MODEL(light_hsl_server_1, APP_KEY_MAX);

DEF_LIGHT_HSL_SETUP_SERVER_MODEL(light_hsl_setup_server_0, APP_KEY_MAX);
DEF_LIGHT_HSL_SETUP_SERVER_MODEL(light_hsl_setup_server_1, APP_KEY_MAX);

static void hsl_processing_and_state_bound(light_hsl_server_t *hsl_server);

void model_status_publish(void)
{
}

static void show_action_set_value(scheduler_server_t *server, uint8_t scene_index)
{
    LOG(3, "show_action_set_value index %x\n", scene_index);
    LOG(3, "year:%d\n", server->msg_format->action_set.year);
    LOG(3, "month:%d\n", server->msg_format->action_set.month);
    LOG(3, "day:%d\n", server->msg_format->action_set.day);
    LOG(3, "hour:%d\n", server->msg_format->action_set.hour);
    LOG(3, "minute:%d\n", server->msg_format->action_set.minute);
    LOG(3, "second:%d\n", server->msg_format->action_set.second);
    LOG(3, "dayofweek:%d\n", server->msg_format->action_set.dayofweek);
    LOG(3, "action:%d\n", server->msg_format->action_set.action);
}

void user_health_attention_0_evt_cb(const mesh_model_evt_t *p_evt)
{
    uint16_t attention_value = p_evt->params.model_value_set.target_value;
    LOG(3, "user_health_attention_0_evt_cb attention:%x\n", attention_value);
    if(attention_value) {

    }else {

    }
}
void user_health_attention_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    uint16_t attention_value = p_evt->params.model_value_set.target_value;
    LOG(3, "user_health_attention_1_evt_cb attention:%x\n", attention_value);
    if(attention_value) {

    }else {

    }
}

static void user_scheduler_0_action_callback(void *param, uint16_t action)
{
    scheduler_server_t *server = (scheduler_server_t *)param; 
    LOG(3, "%s action:%d\n", __func__, action);
    if(action == 0 || action == 1) {
        generic_onoff_server_0.msg_format.present_onoff = action;
        status_switch_onoff_to_level(&generic_onoff_server_0, &generic_level_server_0, light_lightness_server_0.msg_format->lightness_last);
        status_switch_onoff_to_lightness(&generic_onoff_server_0, &light_lightness_server_0);
        status_switch_onoff_to_hsl(&generic_onoff_server_0, &light_hsl_server_0, light_lightness_server_0.msg_format->lightness_last);
        hsl_processing_and_state_bound(&light_hsl_server_0);
    }else if(action == 2) {
        scene_call_user_callback(&scene_setup_server_0, TIME_SCENE_EVT_RECALL, server->msg_format->action_set.scene_number, 0);
    }
}
static void user_scheduler_1_action_callback(void *param, uint16_t action)
{
    LOG(3, "%s action:%d\n", __func__, action);
    scheduler_server_t *server = (scheduler_server_t *)param; 
    if(action == 0 || action == 1) {
        generic_onoff_server_1.msg_format.present_onoff = action;
        status_switch_onoff_to_level(&generic_onoff_server_1, &generic_level_server_1, light_lightness_server_1.msg_format->lightness_last);
        status_switch_onoff_to_lightness(&generic_onoff_server_1, &light_lightness_server_1);
        status_switch_onoff_to_hsl(&generic_onoff_server_1, &light_hsl_server_1, light_lightness_server_1.msg_format->lightness_last);
        hsl_processing_and_state_bound(&light_hsl_server_1);
    }else if(action == 2) {
        scene_call_user_callback(&scene_setup_server_1, TIME_SCENE_EVT_RECALL, server->msg_format->action_set.scene_number, 0);
    }
}

static void user_node_save_scene(scene_server_t *scene_server, light_hsl_server_t *hsl_server, uint8_t scene_index)
{
    save_scene_value_t scene;
    scene.scene_number = scene_server->msg_format->current_scene;
    scene.lightness = hsl_server->msg_format->present_hsl_lightness;
    scene.hue = hsl_server->msg_format->present_hsl_hue;
    scene.saturation = hsl_server->msg_format->present_hsl_saturation;
    LOG(LOG_LVL_INFO,"value:%d %x %x %x %x\n", 
            scene_index, scene.scene_number, scene.lightness, scene.hue, scene.saturation);
    node_save_element_scene(&scene_server->model.base, &scene, scene_index);
}

static void hsl_processing_and_state_bound(light_hsl_server_t *hsl_server)
{
    light_RGB light;

    HSL2RGB(hsl_server->msg_format->present_hsl_hue/65535.0, 
            hsl_server->msg_format->present_hsl_saturation/65535.0,
            hsl_server->msg_format->present_hsl_lightness/65535.0,
            &light);

    LOG(LOG_LVL_INFO,"hsl_processing R:0x%x G:0x%x B:0x%x\n", \
            (uint16_t)(light.R), (uint16_t)(light.G), (uint16_t)(light.B));

    hsl_server->state_bound->bound_cb(hsl_server->state_bound->led_r, (uint16_t)(light.R));
    hsl_server->state_bound->bound_cb(hsl_server->state_bound->led_g, (uint16_t)(light.G));
    hsl_server->state_bound->bound_cb(hsl_server->state_bound->led_b, (uint16_t)(light.B));
}

void user_onoff_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    switch(p_evt->type.onoff_type)
    {
        case ONOFF_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED1= %x %x!!!\n", generic_onoff_server_0.msg_format.present_onoff, p_evt->params.model_value_set.target_value);
            if(generic_onoff_server_0.msg_format.present_onoff != p_evt->params.model_value_set.target_value) {
                generic_onoff_server_0.msg_format.present_onoff = (uint8_t)p_evt->params.model_value_set.target_value;
                status_switch_onoff_to_level(&generic_onoff_server_0, &generic_level_server_0, light_lightness_server_0.msg_format->lightness_last);
                status_switch_onoff_to_lightness(&generic_onoff_server_0, &light_lightness_server_0);
                status_switch_onoff_to_hsl(&generic_onoff_server_0, &light_hsl_server_0, light_lightness_server_0.msg_format->lightness_last);
                hsl_processing_and_state_bound(&light_hsl_server_0);
            }
            break;
        case ONOFF_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"ONOFF_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}
void user_onoff_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    switch(p_evt->type.onoff_type)
    {
        case ONOFF_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED2=%d!!!\n",p_evt->params.model_value_set.target_value);
            if(generic_onoff_server_1.msg_format.present_onoff != p_evt->params.model_value_set.target_value) {
                generic_onoff_server_1.msg_format.present_onoff = (uint8_t)p_evt->params.model_value_set.target_value;
                status_switch_onoff_to_level(&generic_onoff_server_1, &generic_level_server_1, light_lightness_server_1.msg_format->lightness_last);
                status_switch_onoff_to_lightness(&generic_onoff_server_1, &light_lightness_server_1);
                status_switch_onoff_to_hsl(&generic_onoff_server_1, &light_hsl_server_1, light_lightness_server_1.msg_format->lightness_last);
                hsl_processing_and_state_bound(&light_hsl_server_1);
            }
            break;
        case ONOFF_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"ONOFF_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}
void user_level_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3,"user_level_0_evt_cb:%x\n", p_evt->type.level_type);
    switch(p_evt->type.level_type)
    {
        case LEVEL_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED1= %x %x!!!\n", generic_level_server_0.msg_format.present_level, p_evt->params.model_value_set.target_value);
            if(generic_level_server_0.msg_format.present_level != p_evt->params.model_value_set.target_value) {
                generic_level_server_0.msg_format.present_level = p_evt->params.model_value_set.target_value;
                status_switch_level_to_onoff(&generic_level_server_0, &generic_onoff_server_0);
                status_switch_level_to_lightness(&generic_level_server_0, &light_lightness_server_0);
                status_switch_level_to_hsl(&generic_level_server_0, &light_hsl_server_0);
                hsl_processing_and_state_bound(&light_hsl_server_0);
            }
            break;
        case LEVEL_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"LEVEL_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    } 
}
void user_level_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3,"user_level_1_evt_cb:%x\n", p_evt->type.level_type);
    switch(p_evt->type.level_type)
    {
        case LEVEL_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED2=%x!!!\n",p_evt->params.model_value_set.target_value);
            if(generic_level_server_1.msg_format.present_level != p_evt->params.model_value_set.target_value) {
                generic_level_server_1.msg_format.present_level = p_evt->params.model_value_set.target_value;
                status_switch_level_to_onoff(&generic_level_server_1, &generic_onoff_server_1);
                status_switch_level_to_lightness(&generic_level_server_1, &light_lightness_server_1);
                status_switch_level_to_hsl(&generic_level_server_1, &light_hsl_server_1);
                hsl_processing_and_state_bound(&light_hsl_server_1);
            }
            break;
        case LEVEL_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"LEVEL_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}

void user_lightness_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s type:%x\n", __func__, p_evt->type.lightness_type);
    uint16_t lightness = p_evt->params.model_value_set.target_value;
    switch(p_evt->type.lightness_type)
    {
        case LIGHTNESS_ACTUAL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED1=%x %x!!!\n", lightness, light_lightness_server_0.msg_format->present_lightness_actual);
            if(light_lightness_server_0.msg_format->present_lightness_actual != lightness) {
                light_lightness_server_0.msg_format->present_lightness_actual = lightness;
                light_lightness_server_0.msg_format->present_lightness_linear = (lightness * lightness)/65535;
                if(light_lightness_server_0.msg_format->present_lightness_actual)
                    light_lightness_server_0.msg_format->lightness_last = light_lightness_server_0.msg_format->present_lightness_actual;
                status_switch_lightness_to_onoff(&light_lightness_server_0, &generic_onoff_server_0);
                status_switch_lightness_to_level(&light_lightness_server_0, &generic_level_server_0);
                status_switch_lightness_to_hsl(&light_lightness_server_0, &light_hsl_server_0);
                hsl_processing_and_state_bound(&light_hsl_server_0);
            }
            break;
        case LIGHTNESS_ACTUAL_EVT_GET:
            LOG(LOG_LVL_INFO,"LIGHTNESS_ACTUAL_EVT_GET!!!\n");
            break;
        case LIGHTNESS_LINEAR_EVT_SET:
            if(light_lightness_server_0.msg_format->present_lightness_linear != lightness) {
                light_lightness_server_0.msg_format->present_lightness_linear = lightness;
                light_lightness_server_0.msg_format->present_lightness_actual = (uint16_t)sqrt(lightness * 65535);
                if(light_lightness_server_0.msg_format->present_lightness_actual)
                    light_lightness_server_0.msg_format->lightness_last = light_lightness_server_0.msg_format->present_lightness_actual;
                status_switch_lightness_to_onoff(&light_lightness_server_0, &generic_onoff_server_0);
                status_switch_lightness_to_level(&light_lightness_server_0, &generic_level_server_0);
                status_switch_lightness_to_hsl(&light_lightness_server_0, &light_hsl_server_0);
                hsl_processing_and_state_bound(&light_hsl_server_0);
            }
            break;
        case LIGHTNESS_LINEAR_EVT_GET:
            LOG(LOG_LVL_INFO,"LIGHTNESS_LINEAR_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}
void user_lightness_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s type:%x\n", __func__, p_evt->type.lightness_type);
    uint16_t lightness = p_evt->params.model_value_set.target_value;
    switch(p_evt->type.lightness_type)
    {
        case LIGHTNESS_ACTUAL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED2=%x %x!!!\n", lightness, light_lightness_server_0.msg_format->present_lightness_actual);
            if(light_lightness_server_1.msg_format->present_lightness_actual != lightness) {
                light_lightness_server_1.msg_format->present_lightness_actual = lightness;
                light_lightness_server_1.msg_format->present_lightness_linear = (lightness * lightness)/65535;
                if(light_lightness_server_1.msg_format->present_lightness_actual)
                    light_lightness_server_1.msg_format->lightness_last = light_lightness_server_1.msg_format->present_lightness_actual;
                status_switch_lightness_to_onoff(&light_lightness_server_1, &generic_onoff_server_1);
                status_switch_lightness_to_level(&light_lightness_server_1, &generic_level_server_1);
                status_switch_lightness_to_hsl(&light_lightness_server_1, &light_hsl_server_1);
                hsl_processing_and_state_bound(&light_hsl_server_1);
            }
            break;
        case LIGHTNESS_ACTUAL_EVT_GET:
            LOG(LOG_LVL_INFO,"LIGHTNESS_ACTUAL_EVT_GET!!!\n");
            break;
        case LIGHTNESS_LINEAR_EVT_SET:
            if(light_lightness_server_1.msg_format->present_lightness_linear != lightness) {
                light_lightness_server_1.msg_format->present_lightness_linear = lightness;
                light_lightness_server_1.msg_format->present_lightness_actual = (uint16_t)sqrt(lightness * 65535);
                if(light_lightness_server_1.msg_format->present_lightness_actual)
                    light_lightness_server_1.msg_format->lightness_last = light_lightness_server_1.msg_format->present_lightness_actual;
                status_switch_lightness_to_onoff(&light_lightness_server_1, &generic_onoff_server_1);
                status_switch_lightness_to_level(&light_lightness_server_1, &generic_level_server_1);
                status_switch_lightness_to_hsl(&light_lightness_server_1, &light_hsl_server_1);
                hsl_processing_and_state_bound(&light_hsl_server_1);
            }
            break;
        case LIGHTNESS_LINEAR_EVT_GET:
            LOG(LOG_LVL_INFO,"LIGHTNESS_LINEAR_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}

void user_hsl_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s type:%x\n", __func__, p_evt->type.hsl_type);
    uint16_t lightness = p_evt->params.model_hsl_set.target_hsl_lightness;
    uint16_t hue = p_evt->params.model_hsl_set.target_hsl_hue;
    uint16_t saturation = p_evt->params.model_hsl_set.target_hsl_saturation;
    switch(p_evt->type.hsl_type)
    {
        case LIGHT_HSL_SET:
                light_hsl_server_0.msg_format->present_hsl_lightness = lightness;
                light_hsl_server_0.msg_format->present_hsl_hue = hue;
                light_hsl_server_0.msg_format->present_hsl_saturation = saturation;

                status_switch_hsl_to_onoff(&light_hsl_server_0, &generic_onoff_server_0);
                status_switch_hsl_to_level(&light_hsl_server_0, &generic_level_server_0);
                status_switch_hsl_to_lightness(&light_hsl_server_0, &light_lightness_server_0);

                hsl_processing_and_state_bound(&light_hsl_server_0);
            break;
        case LIGHT_HSL_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_GET!!!\n");
            break;
        case LIGHT_HSL_HUE_SET:
            break;
        case LIGHT_HSL_HUE_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_HUE_GET!!!\n");
            break;
        case LIGHT_HSL_SATURATION_SET:
            break;
        case LIGHT_HSL_SATURATION_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_SATURATION_GET!!!\n");
            break;
        case LIGHT_HSL_DEFAULT_SET:
            break;
        case LIGHT_HSL_DEFAULT_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_DEFAULT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    } 
}
void user_hsl_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s type:%x\n", __func__, p_evt->type.hsl_type);
    uint16_t lightness = p_evt->params.model_hsl_set.target_hsl_lightness;
    uint16_t hue = p_evt->params.model_hsl_set.target_hsl_hue;
    uint16_t saturation = p_evt->params.model_hsl_set.target_hsl_saturation;
    switch(p_evt->type.hsl_type)
    {
        case LIGHT_HSL_SET:
            LOG(LOG_LVL_INFO,"!!!LED1=%x!!!\n", lightness);
                light_hsl_server_1.msg_format->present_hsl_lightness = lightness;
                light_hsl_server_1.msg_format->present_hsl_hue = hue;
                light_hsl_server_1.msg_format->present_hsl_saturation = saturation;

                status_switch_hsl_to_onoff(&light_hsl_server_1, &generic_onoff_server_1);
                status_switch_hsl_to_level(&light_hsl_server_1, &generic_level_server_1);
                status_switch_hsl_to_lightness(&light_hsl_server_1, &light_lightness_server_1);
                hsl_processing_and_state_bound(&light_hsl_server_1);
            break;
        case LIGHT_HSL_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_GET!!!\n");
            break;
        case LIGHT_HSL_HUE_SET:
            break;
        case LIGHT_HSL_HUE_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_HUE_GET!!!\n");
            break;
        case LIGHT_HSL_SATURATION_SET:
            break;
        case LIGHT_HSL_SATURATION_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_SATURATION_GET!!!\n");
            break;
        case LIGHT_HSL_DEFAULT_SET:
            break;
        case LIGHT_HSL_DEFAULT_GET:
            LOG(LOG_LVL_INFO,"LIGHT_HSL_DEFAULT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    } 
}
void user_hsl_setup_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s\n", __func__);
}
void user_hsl_setup_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3, "%s\n", __func__);
}

void time_role_process(time_server_t *server)
{
    switch(server->msg_format->role_set.time_role)
    {
        case MESH_TIME_AUTHORITY:
        case MESH_TIME_RELAY:
            break;
        case MESH_TIME_NONE:
        case MESH_TIME_CLIENT:
            break;
        default:
            LOG(3,"server->msg_format->role_set.time_role:%d is wrong\n", server->msg_format->role_set.time_role);
            break;
    }
}
void user_time_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3,"user_time_0_evt_cb:%x\n", p_evt->type.time_type);
    switch(p_evt->type.time_type)
    {
        case TIME_TIME_EVT_SET:
            set_time_msg_format_to_time(&time_server_0);
            LOG(LOG_LVL_INFO,"!!!LED1!!!\n");
            break;
        case TIME_TIME_EVT_GET:
            LOG(LOG_LVL_INFO,"TIME_TIME_EVT_GET!!!\n");
            break;
        case TIME_TIME_ROLE_EVT_SET:
            LOG(LOG_LVL_INFO,"TIME_TIME_ROLE_EVT_SET!!!\n");
            break;
        case TIME_TIME_ROLE_EVT_GET:
            LOG(LOG_LVL_INFO,"TIME_TIME_ROLE_EVT_GET!!!\n");
            break;
        case TIME_TIME_ZONE_EVT_SET:
            LOG(LOG_LVL_INFO,"TIME_TIME_ZONE_EVT_SET!!!\n");
            time_role_process(&time_server_0);
            break;
        case TIME_TIME_ZONE_EVT_GET:
            LOG(LOG_LVL_INFO,"TIME_TIME_ZONE_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    } 
}
void user_time_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3,"user_time_1_evt_cb:%x\n", p_evt->type.time_type);
    switch(p_evt->type.time_type)
    {
        case TIME_TIME_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED2\n");
            set_time_msg_format_to_time(&time_server_1);
            break;
        case TIME_TIME_EVT_GET:
            LOG(LOG_LVL_INFO,"TIME_TIME_EVT_GET!!!\n");
            break;
        case TIME_TIME_ROLE_EVT_SET:
            LOG(LOG_LVL_INFO,"TIME_TIME_ROLE_EVT_SET!!!\n");
            break;
        case TIME_TIME_ROLE_EVT_GET:
            LOG(LOG_LVL_INFO,"TIME_TIME_ROLE_EVT_GET!!!\n");
            break;
        case TIME_TIME_ZONE_EVT_SET:
            LOG(LOG_LVL_INFO,"TIME_TIME_ZONE_EVT_SET!!!\n");
            break;
        case TIME_TIME_ZONE_EVT_GET:
            LOG(LOG_LVL_INFO,"TIME_TIME_ZONE_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}
void user_scene_0_evt_cb(const mesh_model_evt_t *p_evt)
{
    LOG(3,"user_scene_0_evt_cb:%x\n", p_evt->type.scene_type);
    switch(p_evt->type.scene_type)
    {
        case TIME_SCENE_EVT_STORE: 
            {
#if 0
                save_scene_value_t scene;
                scene.scene_number = scene_setup_server_0.msg_format->current_scene;
                scene.lightness = light_hsl_server_0.msg_format.present_hsl_lightness;
                scene.hue = light_hsl_server_0.msg_format.present_hsl_hue;
                scene.saturation = light_hsl_server_0.msg_format.present_hsl_saturation;
                LOG(LOG_LVL_INFO,"!!!LED1!!! value:%d %x %x %x %x\n", 
                        p_evt->params.model_value_set.target_value, scene.scene_number, scene.lightness, scene.hue, scene.saturation);
                node_save_element_scene(&scene_setup_server_0.model.base, &scene, p_evt->params.model_value_set.target_value);
#endif
                user_node_save_scene(&scene_setup_server_0, &light_hsl_server_0, (uint8_t)p_evt->params.model_value_set.target_value);
            }
            break;
        case TIME_SCENE_EVT_RECALL:
            {
                scene_server_0.msg_format->current_scene = p_evt->params.model_value_set.target_value;
                save_scene_value_t scene ;
                node_search_element_scene(0, scene_server_0.msg_format->current_scene, &scene);
                LOG(LOG_LVL_INFO,"TIME_SCENE_EVT_RECALL!!! %x %x %x %x\n",
                        scene.scene_number, scene.lightness, scene.hue, scene.saturation);
                if(scene.scene_number) {
                    light_hsl_server_0.msg_format->present_hsl_lightness = scene.lightness;
                    light_hsl_server_0.msg_format->present_hsl_hue = scene.hue;
                    light_hsl_server_0.msg_format->present_hsl_saturation = scene.saturation;

                    status_switch_hsl_to_onoff(&light_hsl_server_0, &generic_onoff_server_0);
                    status_switch_hsl_to_level(&light_hsl_server_0, &generic_level_server_0);
                    status_switch_hsl_to_lightness(&light_hsl_server_0, &light_lightness_server_0);

                    hsl_processing_and_state_bound(&light_hsl_server_0);
                }
            }
            break;
        case TIME_SCENE_EVT_GET:
            LOG(LOG_LVL_INFO,"TIME_SCENE_EVT_GET!!!\n");
            break;
        case TIME_SCENE_EVT_REGISTER_GET:
            LOG(LOG_LVL_INFO,"TIME_SCENE_EVT_REGISTER_GET!!!\n");
            break;
        case TIME_SCENE_EVT_DELETE:
            {
                save_scheduler_value_t scheduler;
                node_delete_element_scene(&scene_setup_server_0.model.base, p_evt->params.model_value_set.target_value);
                node_search_element_scheduler_from_scene_number(0, p_evt->params.model_value_set.target_value, &scheduler);
                node_delete_element_scheduler(&scheduler_setup_server_0.model.base, scheduler.index);
                LOG(LOG_LVL_INFO,"TIME_SCENE_EVT_DELETE!!! value:%d\n", p_evt->params.model_value_set.target_value);
            }
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    } 
}
void user_scene_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3,"user_scene_1_evt_cb:%x\n", p_evt->type.scene_type);
    switch(p_evt->type.scene_type)
    {
        case TIME_SCENE_EVT_STORE:
            {
                LOG(LOG_LVL_INFO,"!!!LED2!!! value:%d\n", p_evt->params.model_value_set.target_value);
#if 0
                save_scene_value_t scene;
                scene.scene_number = scene_setup_server_1.msg_format->current_scene;
                scene.lightness = light_hsl_server_1.msg_format.present_hsl_lightness;
                scene.hue = light_hsl_server_1.msg_format.present_hsl_hue;
                scene.saturation = light_hsl_server_1.msg_format.present_hsl_saturation;
                node_save_element_scene(&scene_setup_server_1.model.base, &scene, p_evt->params.model_value_set.target_value);
#endif
                user_node_save_scene(&scene_setup_server_1, &light_hsl_server_1, (uint8_t)p_evt->params.model_value_set.target_value);
            }
            break;
        case TIME_SCENE_EVT_RECALL:
            {
                save_scene_value_t scene ;
                node_search_element_scene(0, scene_server_0.msg_format->current_scene, &scene);
                if(scene.scene_number) {
                    light_hsl_server_1.msg_format->present_hsl_lightness = scene.lightness;
                    light_hsl_server_1.msg_format->present_hsl_hue = scene.hue;
                    light_hsl_server_1.msg_format->present_hsl_saturation = scene.saturation;

                    status_switch_hsl_to_onoff(&light_hsl_server_1, &generic_onoff_server_1);
                    status_switch_hsl_to_level(&light_hsl_server_1, &generic_level_server_1);
                    status_switch_hsl_to_lightness(&light_hsl_server_1, &light_lightness_server_1);

                    hsl_processing_and_state_bound(&light_hsl_server_1);
                }
            }
            break;
        case TIME_SCENE_EVT_GET:
            LOG(LOG_LVL_INFO,"TIME_SCENE_EVT_GET!!!\n");
            break;
        case TIME_SCENE_EVT_REGISTER_GET:
            LOG(LOG_LVL_INFO,"TIME_SCENE_EVT_REGISTER_GET!!!\n");
            break;
        case TIME_SCENE_EVT_DELETE:
            {
                save_scheduler_value_t scheduler;
                node_delete_element_scene(&scene_setup_server_1.model.base, p_evt->params.model_value_set.target_value);
                node_search_element_scheduler_from_scene_number(1, p_evt->params.model_value_set.target_value, &scheduler);
                node_delete_element_scheduler(&scheduler_setup_server_1.model.base, scheduler.index);
                scheduler_setup_server_1.msg_format->schedules &= ~(1 << scheduler.index);
                LOG(LOG_LVL_INFO,"TIME_SCENE_EVT_DELETE!!! value:%d\n", p_evt->params.model_value_set.target_value);
            }
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}

void user_scheduler_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3,"user_scheduler_0_evt_cb:%x\n", p_evt->type.scheduler_type);
    switch(p_evt->type.scheduler_type)
    {
        case TIME_SCHEDULER_EVT_GET:
            LOG(LOG_LVL_INFO,"TIME_SCHEDULER_EVT_GET!!!\n");
            break;
        case TIME_SCHEDULER_EVT_ACTION_SET:
            {
                int8_t scene_index = scene_store_scene_number(&scene_setup_server_0, scheduler_setup_server_0.msg_format->action_set.scene_number);
                node_save_element_scheduler(&scheduler_setup_server_0.model.base, (save_scheduler_value_t *)&scheduler_setup_server_0.msg_format->action_set, (uint8_t)p_evt->params.model_value_set.target_value);
                user_node_save_scene(&scene_setup_server_0, &light_hsl_server_0, scene_index);
                show_action_set_value(&scheduler_setup_server_0, (uint8_t)p_evt->params.model_value_set.target_value);
                LOG(LOG_LVL_INFO,"TIME_SCHEDULER_EVT_ACTION_SET!!!\n");
            }
            break;
        case TIME_SCHEDULER_EVT_ACTION_GET:
            LOG(LOG_LVL_INFO,"TIME_SCHEDULER_EVT_ACTION_GET!!!\n");
            node_search_element_scheduler_from_index(0, (uint8_t)p_evt->params.model_value_set.target_value, (save_scheduler_value_t *)&scheduler_setup_server_0.msg_format->action_set);
            show_action_set_value(&scheduler_setup_server_0, (uint8_t)p_evt->params.model_value_set.target_value);
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }

}
void user_scheduler_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    LOG(3,"user_scheduler_1_evt_cb:%x\n", p_evt->type.scheduler_type);
    switch(p_evt->type.scheduler_type)
    {
        case TIME_SCHEDULER_EVT_GET:
            LOG(LOG_LVL_INFO,"TIME_SCHEDULER_EVT_GET!!!\n");
            break;
        case TIME_SCHEDULER_EVT_ACTION_SET:
            {
                int8_t scene_index = scene_store_scene_number(&scene_setup_server_1, scheduler_setup_server_1.msg_format->action_set.scene_number);
                node_save_element_scheduler(&scheduler_setup_server_1.model.base, (save_scheduler_value_t *)&scheduler_setup_server_1.msg_format->action_set, (uint8_t)p_evt->params.model_value_set.target_value);
                user_node_save_scene(&scene_setup_server_1, &light_hsl_server_1, scene_index);
                show_action_set_value(&scheduler_setup_server_1, (uint8_t)p_evt->params.model_value_set.target_value);
                LOG(LOG_LVL_INFO,"TIME_SCHEDULER_EVT_ACTION_SET!!!\n");
            }
            break;
        case TIME_SCHEDULER_EVT_ACTION_GET:
            LOG(LOG_LVL_INFO,"TIME_SCHEDULER_EVT_ACTION_GET!!!\n");
            node_search_element_scheduler_from_index(1, (uint8_t)p_evt->params.model_value_set.target_value, (save_scheduler_value_t *)&scheduler_setup_server_1.msg_format->action_set);
            show_action_set_value(&scheduler_setup_server_1, (uint8_t)p_evt->params.model_value_set.target_value);
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}
static void scene_user_config_server_evt_cb(config_server_evt_type_t type, config_server_evt_param_t * p_param)
{
    //LOG(LOG_LVL_INFO , "scene_user_config_server_evt_cb=%d\n",p_evt->type.scene_type);
}



static void mesh_app_server_init(void)
{
    memset(&scheduler_server_0, 0, sizeof(scheduler_server_t));
    memset(&scheduler_server_1, 0, sizeof(scheduler_server_t));

    memset(&scheduler_setup_server_0, 0, sizeof(scheduler_server_t));
    memset(&scheduler_setup_server_1, 0, sizeof(scheduler_server_t));

    memset(&scene_server_0, 0, sizeof(scene_server_t));
    memset(&scene_server_1, 0, sizeof(scene_server_t));

    memset(&scene_setup_server_0, 0, sizeof(scene_server_t));
    memset(&scene_setup_server_1, 0, sizeof(scene_server_t));

    memset(&time_server_0, 0, sizeof(time_server_t));
    memset(&time_server_1, 0, sizeof(time_server_t));
    memset(&time_setup_server_0, 0, sizeof(time_server_t));
    memset(&time_setup_server_1, 0, sizeof(time_server_t));

    memset(&light_hsl_server_0, 0, sizeof(light_hsl_server_t));
    memset(&light_hsl_server_1, 0, sizeof(light_hsl_server_t));

    memset(&light_lightness_server_0, 0, sizeof(light_lightness_server_t));
    memset(&light_lightness_server_1, 0, sizeof(light_lightness_server_t));

    memset(&generic_transition_server_0, 0, sizeof(generic_transition_server_t));
    memset(&generic_transition_server_1, 0, sizeof(generic_transition_server_t));

    memset(&generic_level_server_0, 0, sizeof(generic_level_server_t));
    memset(&generic_level_server_1, 0, sizeof(generic_level_server_t));

    memset(&generic_onoff_server_0, 0, sizeof(generic_onoff_server_t));
    memset(&generic_onoff_server_1, 0, sizeof(generic_onoff_server_t));

    memset(&health_server_0, 0, sizeof(health_server_t));
    memset(&health_server_1, 0, sizeof(health_server_t));
    //1.init model
    INIT_SCHEDULER_SERVER_MODEL(scheduler_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_scheduler_0_evt_cb);
    INIT_SCHEDULER_SERVER_MODEL(scheduler_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_scheduler_1_evt_cb);
    INIT_SCHEDULER_SETUP_SERVER_MODEL(scheduler_setup_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_scheduler_0_evt_cb);
    INIT_SCHEDULER_SETUP_SERVER_MODEL(scheduler_setup_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_scheduler_1_evt_cb);

    INIT_SCENE_SERVER_MODEL(scene_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_scene_0_evt_cb);
    INIT_SCENE_SERVER_MODEL(scene_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_scene_1_evt_cb);
    INIT_SCENE_SETUP_SERVER_MODEL(scene_setup_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_scene_0_evt_cb);
    INIT_SCENE_SETUP_SERVER_MODEL(scene_setup_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_scene_1_evt_cb);

    INIT_TIME_SERVER_MODEL(time_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_time_0_evt_cb);
    INIT_TIME_SERVER_MODEL(time_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_time_1_evt_cb);
    INIT_TIME_SETUP_SERVER_MODEL(time_setup_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_time_0_evt_cb);
    INIT_TIME_SETUP_SERVER_MODEL(time_setup_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_time_1_evt_cb);

    INIT_LIGHT_HSL_SERVER_MODEL(light_hsl_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_hsl_0_evt_cb);
    INIT_LIGHT_HSL_SERVER_MODEL(light_hsl_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_hsl_1_evt_cb);

    INIT_LIGHT_HSL_SETUP_SERVER_MODEL(light_hsl_setup_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_hsl_setup_0_evt_cb);
    INIT_LIGHT_HSL_SETUP_SERVER_MODEL(light_hsl_setup_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_hsl_setup_1_evt_cb);

    INIT_LIGHT_LIGHTNESS_SERVER_MODEL(light_lightness_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_lightness_0_evt_cb);
    INIT_LIGHT_LIGHTNESS_SERVER_MODEL(light_lightness_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_lightness_1_evt_cb);

    INIT_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, NULL);
    INIT_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, NULL);

    INIT_GENERIC_LEVEL_SERVER_MODEL(generic_level_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_level_0_evt_cb);
    INIT_GENERIC_LEVEL_SERVER_MODEL(generic_level_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_level_1_evt_cb);

    INIT_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_onoff_0_evt_cb);
    INIT_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_onoff_1_evt_cb);

    INIT_HEALTH_SERVER_MODEL(health_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_health_attention_0_evt_cb);
    INIT_HEALTH_SERVER_MODEL(health_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_health_attention_1_evt_cb);
    //3.set initial state
    health_server_0.company_id = MESH_PARAM_CID;
    health_server_1.company_id = MESH_PARAM_CID;

    scheduler_setup_server_0.msg_format = &scheduler_msg[0];
    scheduler_server_0.msg_format = &scheduler_msg[0];

    scheduler_server_1.msg_format = &scheduler_msg[1];
    scheduler_setup_server_1.msg_format = &scheduler_msg[1];

    scheduler_setup_server_0.scheduler_time = &scheduler_time_msg[0];
    scheduler_server_0.scheduler_time = &scheduler_time_msg[0];
    scheduler_server_0.scheduler_time->scheduler_Timer = NULL;

    scheduler_server_0.scheduler_time->action_cb = user_scheduler_0_action_callback;
    scheduler_server_0.scheduler_time->alarm_num = -1;
    memset(scheduler_server_0.scheduler_time->current_alarm_index, -1, SCHSDULER_INDEX_MAX);
    memset(scheduler_server_0.scheduler_time->alarm_timer_index, -1, SCHSDULER_INDEX_MAX);

    scheduler_server_1.scheduler_time = &scheduler_time_msg[1];
    scheduler_setup_server_1.scheduler_time = &scheduler_time_msg[1];
    scheduler_server_1.scheduler_time->scheduler_Timer = NULL;

    scheduler_server_1.scheduler_time->action_cb = user_scheduler_1_action_callback;
    scheduler_server_1.scheduler_time->alarm_num = -1;
    memset(scheduler_server_1.scheduler_time->current_alarm_index, -1, SCHSDULER_INDEX_MAX);
    memset(scheduler_server_1.scheduler_time->alarm_timer_index, -1, SCHSDULER_INDEX_MAX);

    scene_setup_server_0.msg_format = &scene_msg[0];
    scene_server_0.msg_format = &scene_msg[0];

    scene_server_1.msg_format = &scene_msg[1];
    scene_setup_server_1.msg_format = &scene_msg[1];

    time_setup_server_0.msg_format = &time_msg[0];
    time_server_0.msg_format = &time_msg[0];

    time_server_1.msg_format = &time_msg[1];
    time_setup_server_1.msg_format = &time_msg[1];

    light_lightness_server_0.msg_format = &lightness_msg_format[0];
    light_hsl_server_0.msg_format = &hsl_msg_format[0];
    light_lightness_server_1.msg_format = &lightness_msg_format[1];
    light_hsl_server_1.msg_format = &hsl_msg_format[1];

    generic_onoff_server_0.msg_format.present_onoff = 1;

    generic_level_server_0.msg_format.present_level = 0;

    light_lightness_server_0.msg_format->present_lightness_actual = generic_level_server_0.msg_format.present_level + 32768;
    light_lightness_server_0.msg_format->present_lightness_linear = (light_lightness_server_0.msg_format->present_lightness_actual * light_lightness_server_0.msg_format->present_lightness_actual)/65535;
    light_lightness_server_0.msg_format->lightness_last = light_lightness_server_0.msg_format->present_lightness_actual;
    light_hsl_server_0.msg_format->present_hsl_lightness = light_lightness_server_0.msg_format->present_lightness_actual;
    light_hsl_server_0.msg_format->present_hsl_hue = 0;
    light_hsl_server_0.msg_format->present_hsl_saturation = 0;

    generic_level_server_1.msg_format.present_level = 0;
    generic_onoff_server_1.msg_format.present_onoff = 1;

    light_lightness_server_1.msg_format->present_lightness_actual = generic_level_server_1.msg_format.present_level + 32768;
    light_lightness_server_1.msg_format->present_lightness_linear = (light_lightness_server_1.msg_format->present_lightness_actual * light_lightness_server_1.msg_format->present_lightness_actual)/65535;
    light_lightness_server_1.msg_format->lightness_last = light_lightness_server_1.msg_format->present_lightness_actual;
    light_hsl_server_0.msg_format->present_hsl_lightness = light_lightness_server_0.msg_format->present_lightness_actual;
    light_hsl_server_0.msg_format->present_hsl_hue = 0;
    light_hsl_server_0.msg_format->present_hsl_saturation = 0;

    model_common_state_bound_field_set(0, MODEL_STATE_BOUND_LIGHT_LIGHTNESS, hal_set_scheduler_led);
    model_common_state_bound_leds_num_set(0, BX_DONGLE_LED1_R, BX_DONGLE_LED1_G, BX_DONGLE_LED1_B);
    generic_onoff_server_0.state_bound 
        = generic_level_server_0.state_bound 
        = light_lightness_server_0.state_bound 
        = light_hsl_server_0.state_bound 
        = model_common_state_bound_get_from_element_id(0);

    generic_onoff_server_0.delay_trans_timer 
        = generic_level_server_0.delay_trans_timer 
        = light_lightness_server_0.delay_trans_timer 
        = light_hsl_server_0.delay_trans_timer 
        = scene_server_0.delay_trans_timer 
        = scene_setup_server_0.delay_trans_timer 
        = model_common_delay_trans_timer_get_from_element_id(0);

    model_common_state_bound_field_set(1, MODEL_STATE_BOUND_LIGHT_LIGHTNESS, hal_set_scheduler_led);
    model_common_state_bound_leds_num_set(1, LED2_PIN_NUM_MINI, LED2_PIN_NUM_MINI, LED2_PIN_NUM_MINI);
    generic_onoff_server_1.state_bound 
        = generic_level_server_1.state_bound 
        = light_lightness_server_1.state_bound 
        = light_hsl_server_1.state_bound 
        = model_common_state_bound_get_from_element_id(1);
    generic_onoff_server_1.delay_trans_timer 
        = generic_level_server_1.delay_trans_timer 
        = light_lightness_server_1.delay_trans_timer 
        = light_hsl_server_1.delay_trans_timer 
        = scene_server_1.delay_trans_timer 
        = scene_setup_server_1.delay_trans_timer 
        = model_common_delay_trans_timer_get_from_element_id(1);

    LOG(3,"scene_server_0:%p scene_server_1:%p %x %x\n", &scene_server_0, &scene_server_1);
    LOG(3,"server_0_mode:%p server_1_mode:%p\n", &scene_server_0.model, &scene_server_1.model);
    //4.Register config server event callbacks
    regisite_config_server_evt_cb(scene_user_config_server_evt_cb);

    beacon_start();
}

///end of config server application
void user_model_parameter_init(void)
{
    status_switch_hsl_to_onoff(&light_hsl_server_0, &generic_onoff_server_0);
    status_switch_hsl_to_level(&light_hsl_server_0, &generic_level_server_0);
    status_switch_hsl_to_lightness(&light_hsl_server_0, &light_lightness_server_0);
    hsl_processing_and_state_bound(&light_hsl_server_0);

    status_switch_hsl_to_onoff(&light_hsl_server_1, &generic_onoff_server_1);
    status_switch_hsl_to_level(&light_hsl_server_1, &generic_level_server_1);
    status_switch_hsl_to_lightness(&light_hsl_server_1, &light_lightness_server_1);
    hsl_processing_and_state_bound(&light_hsl_server_1);
}

//init user models
void mesh_node_setup(void)
{
    //system init node-element-model tree
    mesh_core_params_t param;
    param.role = MESH_ROLE_CONFIG_SERVER;
    mesh_core_params_set(MESH_CORE_PARAM_MESH_ROLES , &param);

    mesh_app_server_init();
}


