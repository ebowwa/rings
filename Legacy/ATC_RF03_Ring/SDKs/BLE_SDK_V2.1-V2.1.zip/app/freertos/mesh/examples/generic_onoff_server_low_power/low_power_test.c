/**
 ****************************************************************************************
 *
 * @file   low_power_test.c
 *
 * @brief  .
 *
 * @author  jiachuang
 * @date    2019-07-25 15:25
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) BlueX Microelectronics 2019
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "osapp_config.h"

#include "low_power_test.h"
#include "mesh_queued_msg.h"
#include "low_power.h"


/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */




/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/*
 * LOCAL FUNCTIONS DEFINITIONS
 ****************************************************************************************
 */
#define SUBSCRIPTION_LIST_SIZE_PER_FRIEND 10

uint8_t sub_test_count = 0; 
uint8_t sub_trans_num = 0;
uint16_t sub_list[SUBSCRIPTION_LIST_SIZE_PER_FRIEND];

void test_subscribe(void)
{
    sub_test_count ++;
    sub_trans_num++;
    switch(sub_test_count)
    {
        case 1:
            sub_list[0]=0x1122;
            sub_list[1]=0x0003;
            sub_list[2]=0x1122;
            sub_list[3]=0x5678;
            friend_subscription_list_add_tx(sub_trans_num , sub_list , 4);
            break;
        case 2:
            sub_list[0]=0x1122;
            sub_list[1]=0x0004;
            sub_list[2]=0x0005;
            friend_subscription_list_add_tx(sub_trans_num , sub_list , 3);
            break;
        case 3:
            sub_list[0]=0x1122;
            sub_list[1]=0x0003;
            sub_list[2]=0x0005;
            sub_list[3]=0xAAAA;
            //friend_subscription_list_add_tx(sub_trans_num , sub_list , 4);
            friend_subscription_list_remove_tx(sub_trans_num , sub_list , 4);
            break;
        case 4:
            sub_list[0]=0x5678;
            //friend_subscription_list_add_tx(sub_trans_num , sub_list , 1);
            friend_subscription_list_remove_tx(sub_trans_num , sub_list , 1);
            break;
    }
}

void button_action(uint8_t button_idx)
{
//   static uint8_t press = 0;
//   if(press !=0)
//   return;
   if(3 ==button_idx )
   {
       set_lp_default_netkey_global_idx();
       mesh_queued_msg_send((void (*)(void *))friend_request_tx , NULL);
//       press = 1;
   }
   else
   {
       lpn_friend_clear_tx();
   }
}

extern  void send_heartbeat_massage(uint16_t features);

void button4_action(uint16_t counters)
{
    if(1 == counters)
    {
       mesh_queued_msg_send((void (*)(void *))friend_poll_tx, NULL);
    }else if(2 == counters){
      send_heartbeat_massage(8<<8);
      }else if(3 == counters){
      send_heartbeat_massage(0);
      }


//        void friend_poll_tx(void);
/*        mesh_queued_msg_send((void*)lpn_friend_clear_tx , NULL);

    }else if(3 == counters){
       extern void user_health_status_publish(void);
       mesh_queued_msg_send((void*)user_health_status_publish , NULL);

    } else if(3 < counters){
       test_subscribe();
    }*/
  }



#define TEST_RECEIVE_DELAY_MS    200
#define TEST_POOL_TIMEOUT_S      60

void low_power_test_init(void)
{
    friend_req_criteria_t req;
    req.min_queue_size_log = 3;
    req.receive_window_factor = 0;
    req.rssi_factor = 0;

    friend_request_param_set(TEST_POOL_TIMEOUT_S , req , TEST_RECEIVE_DELAY_MS);
    low_power_init();

}


