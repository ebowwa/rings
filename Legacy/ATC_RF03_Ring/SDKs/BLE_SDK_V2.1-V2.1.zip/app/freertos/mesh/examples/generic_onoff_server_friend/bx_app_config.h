#ifndef BX_APP_CONFIG_H_
#define BX_APP_CONFIG_H_

#define configTICK_RATE_HZ                  ( ( TickType_t ) 200 )
#define DEEP_SLEEP_ENABLE 0     //disable sleep
#define ENABLE_ADV_PAYLOD_31BYTE_PATCH 1       //adv payload data max len 31byte
#define BX_DEV_NAME  "APOLLO-MESH"


#define MESH_SCHED_PATCH 1
#define MESH_PROVISION_SERVER_SUPPORT 1
#define MESH_PROVISION_CLIENT_SUPPORT 0
#define CFG_PRF_BXOTAS
 
#endif
