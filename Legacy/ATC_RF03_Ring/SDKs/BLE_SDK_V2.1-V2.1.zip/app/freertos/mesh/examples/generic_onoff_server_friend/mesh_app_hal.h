/**
 ****************************************************************************************
 *
 * @file   mesh_app_hal.h
 *
 * @brief  .
 *
 * @author  Hui Chen
 * @date    2018-09-25 17:29
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup MESH_mesh_app_hal_API Mesh mesh_app_hal API
 * @ingroup MESH_API
 * @brief Mesh mesh_app_hal  API
 *
 * @{
 ****************************************************************************************
 */

#ifndef FREERTOS_APP_MESH_EXAMPLES_SIMPLE_GENERIC_ONOFF_SERVER_MESH_APP_HAL_H_
#define FREERTOS_APP_MESH_EXAMPLES_SIMPLE_GENERIC_ONOFF_SERVER_MESH_APP_HAL_H_

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "mesh_errors.h"
#include "sdk_mesh_config.h"
#include "sdk_mesh_definitions.h"

/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */
/* Apollo dongle board pin num */
//led
#define BX_DONGLE_LED1_R    4
#define BX_DONGLE_LED1_G    2
#define BX_DONGLE_LED1_B    3
#define BX_DONGLE_LED2_R    22
#define BX_DONGLE_LED2_G    20
#define BX_DONGLE_LED2_B    21
//button
#define BX_DONGLE_BTN3      15
#define BX_DONGLE_BTN4      17

/*demo use */
#define LED1_PIN_NUM        30
#define LED2_PIN_NUM        30
#define LED1_PIN_NUM_MINI        BX_DONGLE_LED1_B
#define LED2_PIN_NUM_MINI        BX_DONGLE_LED2_R
#define HEARTBEAT_PIN_NUM_MINI   BX_DONGLE_LED2_G
#define RELAY_PIN_NUM_MINI       BX_DONGLE_LED2_B
#define GATT_BEACON_PIN_NUM_MINI BX_DONGLE_LED1_G
#define PKT_FULL_PIN_NUM_MINI    BX_DONGLE_LED1_R


#define RELAY_PIN_INPUT         30
#define RELAY_PIN_OUTPUT        30
#define GATT_BEACON_PIN_INPUT   30
#define GATT_BEACON_PIN_OUTPUT  30



#define BTN3_PIN_NUM        BX_DONGLE_BTN3
#define BTN4_PIN_NUM        BX_DONGLE_BTN4

#define HAL_TIMER_TICK   200               // unit: ms
#define HEARTBEAT_BLINKY_TICK   1000               // unit: ms
#define HAL_RESET_TICK   3000               // unit: ms
#define HAL_RESET_DELAY_TICK   3000               // unit: ms
#define HAL_GATT_DELAY_TICK   60000               // unit: ms
#define HAL_USER_INPUT_TICK  10000               // unit: ms
/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */


/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
void hal_set_led(uint8_t io_num, uint16_t on_off);
void hal_init_leds(void);
void hal_init_buttons(void);
void hal_init_heartbeat_led(void);
void hal_set_heartbeat_led(uint8_t on_off);
void hal_heartbeat_init(void);
void hal_relay_led_set(uint8_t state);
void make_light_blink(uint8_t count);
void make_user_attention(void);

#endif /* FREERTOS_APP_MESH_EXAMPLES_SIMPLE_GENERIC_ONOFF_SERVER_MESH_APP_HAL_H_ */ 
/// @} MESH_mesh_app_hal_API

