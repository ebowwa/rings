/**
 ****************************************************************************************
 *
 * @file   node_setup.h
 *
 * @brief  .
 *
 * @author  ZHAOYUNLIU
 * @date    2018-11-27 13:45
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup MESH_mesh_app_API Mesh mesh_app API
 * @ingroup MESH_API
 * @brief Mesh mesh_app  API
 *
 * @{
 ****************************************************************************************
 */

#ifndef APP_FREERTOS_MESH_EXAMPLES_SIMPLE_LIGHT_HSL_SERVER_NODE_SETUP_H_
#define APP_FREERTOS_MESH_EXAMPLES_SIMPLE_LIGHT_HSL_SERVER_NODE_SETUP_H_

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "mesh_errors.h"
#include "sdk_mesh_config.h"
#include "sdk_mesh_definitions.h"


/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */

/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
void mesh_node_setup(void);
void user_model_parameter_init(void);
void model_status_publish(void);



#endif /* APP_FREERTOS_MESH_EXAMPLES_SIMPLE_LIGHT_HSL_SERVER_NODE_SETUP_H_ */ 
/// @} MESH_mesh_app_API

