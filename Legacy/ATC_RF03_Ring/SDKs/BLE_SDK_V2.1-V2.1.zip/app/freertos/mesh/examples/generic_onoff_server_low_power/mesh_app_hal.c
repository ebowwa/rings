/**
 ****************************************************************************************
 *
 * @file   mesh_app_hal.c
 *
 * @brief  .
 *
 * @author  Hui Chen
 * @date    2018-09-25 17:29
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "osapp_config.h"

#include "mesh_app_hal.h"
#include "io_ctrl.h"
#include "plf.h"
#include "mesh_core_api.h"
#include "app_pwm.h"
#include "proxy_s.h"
#include "node_setup.h"

#include "low_power_test.h"



/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */
#define GATT_BEACON_ON  1
#define GATT_BEACON_OFF 0
/*
 * ENUMERATIONS
 ****************************************************************************************
 */

typedef enum
{
    RESET_CHECK = 0,
    RESET_DELAY = 1,
    RESET_DONE = 2,
}RESET_PHASE_T;

/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */




/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */
 
mesh_timer_t gal_heartbeat_Timer;
static app_pwm_inst_t bxpwm = PWM_INSTANCE();

uint8_t button3_pressed = 0;
uint8_t button4_pressed = 0;
uint16_t button4_counters = 0;

uint8_t reset_flag = 0;
RESET_PHASE_T reset_phase = RESET_CHECK;
uint8_t gatt_beacon_flag = 1;
uint8_t prov_auth_flag = 0;
uint8_t prov_auth_count = 0;
uint8_t user_attention_flag = 0;
uint8_t user_attention_input = 0;
static void user_input_rec(void);
#define POWER_TEST_FLAG 1
/*
 * LOCAL FUNCTIONS DEFINITIONS
 ****************************************************************************************
 */

void hal_set_led(uint8_t io_num, uint16_t on_off)
{
    if(io_num == 1) {
        if(on_off == 1)
        {
            //data set  io on
            //       io_pin_clear(LED1_PIN_NUM);
            io_pin_clear(LED1_PIN_NUM_MINI);
        }
        else
        {
            //data set  io off
            //        io_pin_set(LED1_PIN_NUM);
            io_pin_set(LED1_PIN_NUM_MINI);
        }
    }else if(io_num == 2) {
        if(on_off == 1)
        {
            //data set  io on
            io_pin_clear(LED2_PIN_NUM);
            io_pin_clear(LED2_PIN_NUM_MINI);
        }
        else
        {
            //data set  io off
            io_pin_set(LED2_PIN_NUM);
            io_pin_set(LED2_PIN_NUM_MINI);
        }
    }
}

void hal_set_heartbeat_led(uint8_t on_off)
{

    if(on_off == 1)
    {
        //data set  io on
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_2, 100, 10);
    }
    else
    {
        //data set  io off
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_2, 100, 0);
    }
}


void hal_set_relay_led(uint8_t on_off)
{
    static  uint8_t last_status = 1;
    if(on_off == last_status)
    {
        return;
    }
    LOG(LOG_LVL_INFO,"hal_set_relay_led %d \n",on_off);
    last_status = on_off;
    if(!on_off)
    {
        mesh_core_params_t core_param;
        core_param.relay = MESH_FEATURE_ENABLED;
        mesh_core_params_set(MESH_CORE_PARAM_FEATURE_RELAY,&core_param);
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_0, 100, 1);
    }
    else
    {
        mesh_core_params_t core_param;
        core_param.relay = MESH_FEATURE_DISABLED;
        mesh_core_params_set(MESH_CORE_PARAM_FEATURE_RELAY,&core_param);
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_0, 100, 0);
    }
}

void hal_set_gatt_led(uint8_t on_off)
{
    static  uint8_t last_status = 1;

    if(on_off == last_status)
    {
        return;
    }
    LOG(LOG_LVL_INFO,"hal_set_gatt_led %d \n",on_off);
    last_status = on_off;
    if(!on_off)
    {
        gatt_beacon_flag = GATT_BEACON_OFF;
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_1, 100, 1);

    }
    else
    {
        gatt_beacon_flag  = GATT_BEACON_ON;
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_1, 100, 0);
    }
}
 
void hal_app_pwm_init(void)
{

    bxpwm.channel[PWM_CHANNEL_0].pin_num = RELAY_PIN_NUM_MINI;
    bxpwm.channel[PWM_CHANNEL_1].pin_num = GATT_BEACON_PIN_NUM_MINI;
    bxpwm.channel[PWM_CHANNEL_2].pin_num = HEARTBEAT_PIN_NUM_MINI;
    app_pwm_init(&bxpwm.inst);
	app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_0, 100, 0);
    app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_1, 100, 0);
    app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_1, 100, 1);

}

void hal_app_switch_init(void)
{
    io_cfg_output(RELAY_PIN_OUTPUT);
    io_cfg_output(GATT_BEACON_PIN_OUTPUT);
    
    //io_pin_set(RELAY_PIN_OUTPUT);
    //io_pin_set(GATT_BEACON_PIN_OUTPUT);
    io_pin_clear(RELAY_PIN_OUTPUT);
    io_pin_clear(GATT_BEACON_PIN_OUTPUT);

    io_cfg_input(RELAY_PIN_INPUT);
    io_cfg_input(GATT_BEACON_PIN_INPUT);
    
    io_pin_pull_write(RELAY_PIN_INPUT,IO_PULL_UP);
    io_pin_pull_write(GATT_BEACON_PIN_INPUT,IO_PULL_UP);


     
}


void hal_init_leds(void)
{
#if !POWER_TEST_FLAG
    //1. io dir
   // io_cfg_output(LED1_PIN_NUM);
    io_cfg_output(LED2_PIN_NUM);
    io_cfg_output(LED1_PIN_NUM_MINI);
    io_cfg_output(LED2_PIN_NUM_MINI);
    io_cfg_output(RELAY_PIN_NUM_MINI);
    io_cfg_output(GATT_BEACON_PIN_NUM_MINI);
    io_cfg_output(PKT_FULL_PIN_NUM_MINI);


    //2. set output
 //  io_pin_clear(LED1_PIN_NUM);
    io_pin_clear(LED2_PIN_NUM);
    io_pin_clear(LED1_PIN_NUM_MINI);
    io_pin_clear(LED2_PIN_NUM_MINI);
    
 //   io_pin_set(LED1_PIN_NUM_MINI);
//    io_pin_set(LED2_PIN_NUM_MINI);
    io_pin_set(RELAY_PIN_NUM_MINI);
    io_pin_set(GATT_BEACON_PIN_NUM_MINI);
    io_pin_set(PKT_FULL_PIN_NUM_MINI);

    //3 relay switch
    hal_app_pwm_init();

    hal_app_switch_init();
#else
   // io_cfg_output(LED1_PIN_NUM);
    //io_cfg_input(LED2_PIN_NUM);
    //io_cfg_input(LED1_PIN_NUM_MINI);
   // io_cfg_input(LED2_PIN_NUM_MINI);
    //io_cfg_input(RELAY_PIN_NUM_MINI);
    //io_cfg_input(GATT_BEACON_PIN_NUM_MINI);
    //io_cfg_input(PKT_FULL_PIN_NUM_MINI);
    //io_cfg_output(RELAY_PIN_OUTPUT);
    //io_cfg_output(RELAY_PIN_INPUT);
    //io_cfg_output(LED2_PIN_NUM);
    io_cfg_output(2);
    io_cfg_output(3);
    io_cfg_output(4);
    io_cfg_output(5);
#endif
}

#if !POWER_TEST_FLAG
void hal_init_heartbeat_led(void)
{

}
#endif

void hal_relay_led_set(uint8_t state)
{
    
    if(MESH_FEATURE_ENABLED == state)
    {
        hal_set_relay_led(1);//relay state  enable
    }
    else//MESH_FEATURE_DISABLED
    {
        hal_set_relay_led(0);//relay state  disable
    }
}
// button

void hal_button3_cb(void)
{
    button3_pressed = 1;
//    reset_flag = 1;
    user_input_rec();
    LOG(LOG_LVL_INFO,"hal_button3_cb\n");

    button_action(3);

}
void hal_button4_cb(void)
{
   button4_pressed = 1;
   user_input_rec();
//   reset_flag = 1;
   LOG(LOG_LVL_INFO,"hal_button4_cb\n");
   button4_counters++;
//   button_action(4);


}
void hal_init_buttons(void)
{
    //1. io dir
    io_cfg_input(BTN3_PIN_NUM);
    io_cfg_input(BTN4_PIN_NUM);
    //2. pull
    io_pin_pull_write(BTN3_PIN_NUM,IO_PULL_UP);
    io_pin_pull_write(BTN4_PIN_NUM,IO_PULL_UP);
    //3. int cfg
    io_ext_int_cfg(BTN3_PIN_NUM,EXT_INT_TRIGGER_NEG_EDGE,hal_button3_cb);
    io_ext_int_cfg(BTN4_PIN_NUM,EXT_INT_TRIGGER_NEG_EDGE,hal_button4_cb);
    //4. en
    io_ext_int_en(BTN3_PIN_NUM,true);
    io_ext_int_en(BTN4_PIN_NUM,true);
}


static void relayTimeoutCallback(void)
{
    uint8_t relay = io_pin_read(RELAY_PIN_INPUT);
    uint8_t gatt =  io_pin_read(GATT_BEACON_PIN_INPUT);
    hal_set_relay_led(relay);
    hal_set_gatt_led(gatt);
}

static void resetTimeCheck(void)
{
    static uint32_t reset_counter = 0;
    uint8_t press3 =  io_pin_read(BTN3_PIN_NUM);
    uint8_t press4 =  io_pin_read(BTN4_PIN_NUM);
    if(reset_phase == RESET_CHECK)
    {
        if(press3 == 0 && press4 == 0)
        {
            LOG(LOG_LVL_INFO,"RESET_DELAY entry \n");
            reset_phase = RESET_DELAY;
            reset_counter = 0;
            return;
        }
    }
    else if(reset_phase == RESET_DELAY)
    {
        if(press3 != 0 || press4 !=0)
        {
            reset_phase = RESET_CHECK;
            reset_counter = 0;
            return;
        }
        reset_counter ++;
        if(reset_counter >= (HAL_RESET_DELAY_TICK/HAL_TIMER_TICK))
        {
            
            LOG(LOG_LVL_INFO,"RESET_DONE entry \n");
            reset_phase = RESET_DONE;
            reset_counter = 0;
            return;
        }
   }
   else if(reset_phase == RESET_DONE)
   {
       LOG(LOG_LVL_INFO,"RESET_NODE !!!!! \n");
       mesh_core_system_set(MESH_CORE_SYSTEM_ALL_RESET);
   }
}

static void heartbeatTimeoutCallback(mesh_timer_t xTimer)
{
    static uint8_t on_off = 1;
    static uint32_t tick_counter = 0;
    tick_counter ++;
    if(prov_auth_flag == 1 || user_attention_flag == 1)
    {
        return ;
    }

    if((HEARTBEAT_BLINKY_TICK/HAL_TIMER_TICK) >= tick_counter && reset_phase != RESET_DELAY )
    {
       return;
    }
    hal_set_heartbeat_led(on_off);
    on_off = 1 - on_off;
    tick_counter = 0;
}

static void gattbeaconTimeCheck(void)
{
    static uint8_t last_status = GATT_BEACON_ON;
    static uint32_t tick_counter = 0;

    if(gatt_beacon_flag != last_status)
    {
        mesh_core_params_t param;
        mesh_core_params_get(MESH_CORE_PARAM_IS_PROVISIONED , &param);
        if(gatt_beacon_flag == GATT_BEACON_OFF  && param.is_provisioned)
        {
            if(tick_counter > (HAL_GATT_DELAY_TICK/HAL_TIMER_TICK))
            {
               proxy_service_beacon_stop();
               LOG(LOG_LVL_INFO,"proxy_service_beacon_stop !!!!! \n");
               last_status = gatt_beacon_flag;
               tick_counter = 0;
            }
            else 
            {
                tick_counter++;
            }
        }
        else if(gatt_beacon_flag == GATT_BEACON_ON && param.is_provisioned)
        {
            proxy_service_beacon_restart();
            last_status = gatt_beacon_flag;
            tick_counter = 0;
            LOG(LOG_LVL_INFO,"proxy_service_beacon_restart !!!!! \n");
        }
    }
}

static void user_input_rec(void)
{
    if(user_attention_flag == 0)
    {
        return;
    }
    user_attention_input ++;
}

static void attentionTimeoutCallback(mesh_timer_t xTimer)
{
    extern void  notify_user_input_finish(uint8_t user_input);
    static uint8_t blink_count = 0;

    if(user_attention_flag == 0)
    {
        return;
    }
    blink_count ++;
    if(blink_count >= HAL_USER_INPUT_TICK/HAL_TIMER_TICK)
    {
        blink_count = 0;
        user_attention_flag = 0;
        notify_user_input_finish(user_attention_input);
    }
}


static void provTimeoutCallback(mesh_timer_t xTimer)
{
    #define ATTATION_TIME 10
    #define BLINK_TIME 5
    static uint8_t blink_times = 0;
    static uint8_t blink_count = 0;
    static uint8_t on_off = 0;
    if(prov_auth_flag == 0)
    {
        return;
    }
    blink_count ++;

    if(blink_count  <= ATTATION_TIME)
    {
        hal_set_heartbeat_led(1);
        on_off = 0;
        return;
    }

    if((prov_auth_count + ATTATION_TIME  -blink_count ) == 0)
    {
        blink_count = 0;
        blink_times ++;
        if(blink_times >=BLINK_TIME)
        {
            blink_times =0;
            blink_count = 0;
            prov_auth_flag = 0;
            return;
        }
    }
    hal_set_heartbeat_led(on_off);
    on_off = 1 - on_off;
    
}


static void buttonTimeoutCallback(mesh_timer_t xTimer)
{
    #define CHECK_TIME 3000
    static uint16_t button_times = 0;
    static uint16_t check_counters = 0;
    if(button4_counters == 0)
    {
        return;
    }
    if(button4_counters != check_counters)
    {
        check_counters = button4_counters;
        button_times++;
        return;
    }
    button_times++;
    if(button_times  <= CHECK_TIME/HAL_TIMER_TICK)
    {
        return;
    }
    button4_action(button4_counters);
    button4_counters  = 0;
    check_counters = 0;
    button_times = 0;
    
}


static void halTimeoutCallback(mesh_timer_t xTimer)
{
    resetTimeCheck();
    provTimeoutCallback(xTimer);
    attentionTimeoutCallback(xTimer);
    heartbeatTimeoutCallback(xTimer);
#if  MESH_TOOLS_CFG_RELAY_TEST
    relayTimeoutCallback();
#endif
    gattbeaconTimeCheck();
    buttonTimeoutCallback(xTimer);
}



void hal_timer_init(void)
{
     gal_heartbeat_Timer = xTimerCreate("gal_heartbeat_Timer",pdMS_TO_TICKS(HAL_TIMER_TICK),pdTRUE,(void *)0,halTimeoutCallback);
#if !POWER_TEST_FLAG
     if(gal_heartbeat_Timer != NULL)
     {
         xTimerStart(gal_heartbeat_Timer,0);
     }
 #endif
}

void hal_heartbeat_init(void)
{
#if !POWER_TEST_FLAG
    hal_init_heartbeat_led();
#endif
    hal_timer_init();
}



void make_light_blink(uint8_t count)
{
     prov_auth_flag = 1;
     prov_auth_count = count;
     
}


void make_user_attention(void)
{
    user_attention_flag = 1;
    user_attention_input = 0;
}

