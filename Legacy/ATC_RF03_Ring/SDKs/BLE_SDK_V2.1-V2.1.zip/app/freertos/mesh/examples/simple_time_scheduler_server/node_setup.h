/**
 ****************************************************************************************
 *
 * @file   node_setup.h
 *
 * @brief  .
 *
 * @author  liuzy
 * @date    2018-09-25 17:20
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup MESH_mesh_app_API Mesh mesh_app API
 * @ingroup MESH_API
 * @brief Mesh mesh_app  API
 *
 * @{
 ****************************************************************************************
 */

#ifndef FREERTOS_APP_MESH_EXAMPLES_SIMPLE_TIME_SCHEDULER_SERVER_NODE_SETUP_H_
#define FREERTOS_APP_MESH_EXAMPLES_SIMPLE_TIME_SCHEDULER_SERVER_NODE_SETUP_H_

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include <stdint.h>

/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */


/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
//TODO:THIS IS ONLY USED　FIX WARNINGS !!
void mesh_node_setup(void);
void user_model_parameter_init(void);
void model_status_publish(void);



#endif /* FREERTOS_APP_MESH_EXAMPLES_SIMPLE_TIME_SCHEDULER_SERVER_NODE_SETUP_H_ */ 
/// @} MESH_mesh_app_API

