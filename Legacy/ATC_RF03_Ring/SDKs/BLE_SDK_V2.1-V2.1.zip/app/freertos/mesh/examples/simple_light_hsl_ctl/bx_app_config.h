#ifndef BX_APP_CONFIG_H_
#define BX_APP_CONFIG_H_


#define DEEP_SLEEP_ENABLE 0     //disable sleep
#define ENABLE_ADV_PAYLOD_31BYTE_PATCH 1       //adv payload data max len 31byte
#define BX_DEV_NAME "MESH_RGB_CTL" 
#define MESH_SCHED_PATCH 1
#define MESH_PROVISION_SERVER_SUPPORT 1
#define MESH_PROVISION_CLIENT_SUPPORT 0

#define RF_TX_POWER 0x1

#endif
