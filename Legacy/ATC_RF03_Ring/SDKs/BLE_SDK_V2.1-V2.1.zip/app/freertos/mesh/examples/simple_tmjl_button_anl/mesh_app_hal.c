/**
 ****************************************************************************************
 *
 * @file   mesh_app_hal.c
 *
 * @brief  .
 *
 * @author  ZHAOYUNLIU
 * @date    2018-11-27 13:48
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "osapp_config.h"

#include "mesh_app_hal.h"
#include "io_ctrl.h"
#include "plf.h"
#include "mesh_core_api.h"
#include "app_pwm.h"
#include "proxy_s.h"
#include "app_gpio.h"
#include "light_ctl_server.h"
#include "light_lightness_server.h"
#include "timer_wrapper.h"
#include "mesh_sched.h"
#include "mesh_queued_msg.h"
#include "node_save_common.h"
#include "unprov_device_intf.h"
#include "node_setup.h"

/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */
#define GATT_BEACON_ON  1
#define GATT_BEACON_OFF 0
/*
 * ENUMERATIONS
 ****************************************************************************************
 */

typedef enum
{
    RESET_CHECK = 0,
    RESET_DELAY = 1,
    RESET_DONE = 2,
}RESET_PHASE_T;

/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */




/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */
 
mesh_timer_t gal_heartbeat_Timer;
static app_pwm_inst_t bxpwm = PWM_INSTANCE();

mesh_timer_t xTimerButton;
StaticTimer_t xTimerButtonBuffers;

mesh_timer_t xTimerButtonLPress;
StaticTimer_t xTimerButtonLPressBuffers;

#define HAL_TIMER_BUTTON_INTERVAL_MS 10
#define HAL_TIMER_BUTTON_LPRESS_INTERVAL_MS 40
#define HAL_TIMER_BUTTON_LPRESS_TIMEOUT_MS 320

#define ONOFF_BUTTON_PUSH             (1 << BTN_PIN_FOR_ONOFF)
#define WARM_BUTTON_PUSH              (1 << BTN_PIN_FOR_WARM)
#define WHITE_BUTTON_PUSH             ((1 << BTN_PIN_FOR_ONOFF) | (1 << BTN_PIN_FOR_ADD_LIGHTNESS))
#define REDUCE_LIGHTNESS_BUTTON_PUSH  (1 << BTN_PIN_FOR_REDUCE_LIGHTNESS)
#define ADD_LIGHTNESS_BUTTON_PUSH     (1 << BTN_PIN_FOR_ADD_LIGHTNESS)
#define MULTIFUNC_BUTTON_PUSH         (1 << BTN_PIN_FOR_MULTIFUNC)

#define ALL_BUTTON_PUSH                (ONOFF_BUTTON_PUSH | WARM_BUTTON_PUSH | WHITE_BUTTON_PUSH\
                                            | REDUCE_LIGHTNESS_BUTTON_PUSH | ADD_LIGHTNESS_BUTTON_PUSH | MULTIFUNC_BUTTON_PUSH)

#define HAL_DEBOUNCE_NM 4
#define ARRAY_MAX 10

#define CKECK_ONE_BUTTON_PRESS_TIME_MS 400
#define CKECK_ONE_BUTTON_LONG_PRESS_TIME_MS (600 - HAL_DEBOUNCE_NM * HAL_TIMER_BUTTON_INTERVAL_MS)
#define HAL_TIMER_ONOFF_BUTTON_LPRESS_TIMEOUT_MS (3000 - - HAL_DEBOUNCE_NM * HAL_TIMER_BUTTON_INTERVAL_MS) 

static uint32_t gpio_val_array[ARRAY_MAX];
static uint32_t gpio_lpress_check;
static uint8_t current_index = 0;
static uint8_t press_send_pkt_flag = 0;

int8_t send_pkt_type = -1;


/*
 * LOCAL FUNCTIONS DEFINITIONS
 ****************************************************************************************
 */

void hal_set_onoff_led(uint8_t io_num, uint16_t on_off)
{
    if(io_num == BX_DONGLE_LED1_B) {
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_0, 0, 0xffff);
    }else if(io_num == BX_DONGLE_LED1_G) {
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_3, 0, 0xffff);
    }else if(io_num == BX_DONGLE_LED1_R) {
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_4, 0, 0xffff);
    }else if(io_num == BX_DONGLE_LED2_R) {
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_1, 0, 0xffff);
    }else if(io_num == BX_DONGLE_LED2_G) {
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_2, 0, 0xffff);
    }
}

void hal_set_lightness_led(uint8_t io_num, uint16_t lightness)
{
    if(io_num == BX_DONGLE_LED1_B) {
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_0, lightness, 0xffff - lightness);
        LOG(3,"hal_set_lightness_led B lightness:%x\n", lightness);
    }else if(io_num == BX_DONGLE_LED1_G) {
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_3, lightness, 0xffff - lightness);
        LOG(3,"hal_set_lightness_led G lightness:%x\n", lightness);
    }else if(io_num == BX_DONGLE_LED1_R) {
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_4, lightness, 0xffff - lightness);
        LOG(3,"hal_set_lightness_led R lightness:%x\n", lightness);
    }else if(io_num == BX_DONGLE_LED2_R) {
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_1, lightness, 0xffff - lightness);
        LOG(3,"hal_set_lightness_led2 lightness:%x \n", lightness);
    }else if(io_num == BX_DONGLE_LED2_G) {
        app_pwm_set_time(&bxpwm.inst, PWM_CHANNEL_2, lightness, 0xffff - lightness);
        LOG(3,"hal_set_lightness_led2 lightness:%x \n", lightness);
    }
}

void hal_set_hsl_led(uint8_t io_num, uint16_t lightness)
{
    LOG(3, "io_num:%d lightness:%x\n", io_num, lightness);
    if(lightness != 0x0)
        hal_set_lightness_led(io_num, lightness);
    else
        hal_set_onoff_led(io_num, 0);
}


void hal_init_leds(void)
{
    io_cfg_output(BTN_LED_INDICATOR_LIGHT);
    io_pin_set(BTN_LED_INDICATOR_LIGHT);

}

static uint32_t read_all_button_state()
{
    uint32_t gpio_value = io_read_all();

    //LOG(3, "read_all_button_state:%x %x\n", gpio_value, io_read_all());
    return (gpio_value & WARM_BUTTON_PUSH) | ((~gpio_value) & (~WARM_BUTTON_PUSH));
}

void hal_button_warn_cb(void)
{
    user_adjust_light_to_warm();
    LOG(LOG_LVL_INFO,"hal_button_warn_cb\n");
}

void hal_button_white_cb(void)
{
    user_adjust_light_to_white();
    LOG(LOG_LVL_INFO,"hal_button_white_cb\n");
}

void hal_button_reduce_lightness_cb(void)
{
    LOG(3, "hal_button_reduce_lightness_cb\n");
    user_adjust_light_lightness(0);
}

void hal_button_add_lightness_cb(void)
{
    LOG(3, "hal_button_add_lightness_cb\n");
    user_adjust_light_lightness(1);
}

void hal_button_onoff_cb(void)
{

    LOG(3, "hal_button_onoff_cb\n");

    user_adjust_light_onoff();
}

void hal_button_multifunc_cb(void)
{

    LOG(3, "hal_button_multifunc_cb\n");

    user_adjust_to_neutral_light();
}
void call_mesh_sched_start_scan(void)
{
    //LOG(3, "call_mesh_sched_start_scan\n");
    mesh_sched_start_scan();
}

void hal_dis_all_button(void)
{
    mesh_run(call_mesh_sched_start_scan, portMAX_DELAY, true);
    io_ext_int_mask(BTN_PIN_FOR_WARM, false);
    io_ext_int_mask(BTN_PIN_FOR_REDUCE_LIGHTNESS, false);
    io_ext_int_mask(BTN_PIN_FOR_ADD_LIGHTNESS, false);
    io_ext_int_mask(BTN_PIN_FOR_ONOFF, false);
    io_ext_int_mask(BTN_PIN_FOR_MULTIFUNC, false);
}

void hal_common_button_cb(void)
{
    LOG(3, "hal_common_button_cb gpio_read_all_button_state:%x\n", read_all_button_state()); 
    hal_dis_all_button();
    clear_need_send_pkt_type();
    xTimerStart( xTimerButton, pdFALSE);
}

void hal_scan_stop_callback(void)
{
    LOG(3,"hal_scan_stop_callback\n"); 
}
void call_mesh_sched_stop_scan(void)
{
    mesh_sched_stop_scan(hal_scan_stop_callback);
}
void hal_en_all_button(void)
{
#if 0
    if(!get_need_send_pkt_type())
        mesh_run(call_mesh_sched_stop_scan, true);
#endif

    io_ext_int_en(BTN_PIN_FOR_WARM, true);
    io_ext_int_en(BTN_PIN_FOR_REDUCE_LIGHTNESS, true);
    io_ext_int_en(BTN_PIN_FOR_ADD_LIGHTNESS, true);
    io_ext_int_en(BTN_PIN_FOR_ONOFF, true);
    io_ext_int_en(BTN_PIN_FOR_MULTIFUNC, true);
}
static void scan_stop_then_delete_mesh_dir(void)
{
    node_delete_mesh_dir();
}

static void hal_lpress_reset_system(void)
{
    node_save_system_onoffcount(0xf0);
    node_save_write_through();
    mesh_sched_stop_scan(scan_stop_then_delete_mesh_dir);
    //mesh_core_system_set(MESH_CORE_SYSTEM_ALL_RESET);
}

uint32_t check_button_is_pressed(uint32_t *gpio_val_array, uint8_t len, uint8_t check_count, uint32_t check_button)
{
    uint8_t press_count = 0;
    uint8_t index = current_index;
    uint32_t find_button = 0;

    for(int i = 0; i < len; i++) {
        if(gpio_val_array[--index % ARRAY_MAX] & check_button) {
            find_button |= gpio_val_array[index % ARRAY_MAX] & check_button;
        }
    }

    index = current_index;

    for(int i = 0; i < len; i++) {
       // LOG(3, "show gpio_val_array[%x]:%x %x\n", \
                (index-1)%ARRAY_MAX, gpio_val_array[(index-1)%ARRAY_MAX], gpio_val_array[(index-1)%ARRAY_MAX] & check_button);
        if(gpio_val_array[--index % ARRAY_MAX] & check_button)
            press_count++;
    }

    LOG(3," press_count:%x check_count:%x find_button:%x check_button:%x\n", press_count, check_count, find_button, check_button);
    if(press_count >= check_count)
        return find_button;
    else
        return 0;
}

static void call_one_button_press_callback(uint32_t press_result)
{
    if(press_send_pkt_flag)
        return;

    press_send_pkt_flag = 1;

    if(!get_is_provisioned())
        return;

    if(((WARM_BUTTON_PUSH) & press_result) == WARM_BUTTON_PUSH)
    {
        mesh_run(hal_button_warn_cb, portMAX_DELAY, true);
    }
    else if(((WHITE_BUTTON_PUSH) & press_result) == WHITE_BUTTON_PUSH)
    {
        mesh_run(hal_button_white_cb, portMAX_DELAY, true);
    }
    else if(((REDUCE_LIGHTNESS_BUTTON_PUSH) & press_result) == REDUCE_LIGHTNESS_BUTTON_PUSH)
    {
        mesh_run(hal_button_reduce_lightness_cb, portMAX_DELAY, true);
    }
    else if(((ADD_LIGHTNESS_BUTTON_PUSH) & press_result) == ADD_LIGHTNESS_BUTTON_PUSH)
    {
        mesh_run(hal_button_add_lightness_cb,portMAX_DELAY, true);
    }
    else if(((ONOFF_BUTTON_PUSH) & press_result) == ONOFF_BUTTON_PUSH)
    {
        mesh_run(hal_button_onoff_cb,portMAX_DELAY, true);
    }
    else if(((MULTIFUNC_BUTTON_PUSH) & press_result) == MULTIFUNC_BUTTON_PUSH)
    {
        mesh_run(hal_button_multifunc_cb, portMAX_DELAY, true);
    } 
}

static void stepless_add_temperature(void)
{
    if(!get_is_provisioned())
        return;

    user_adjust_stepless_temerature(1, ONE_STEP_OF_TEMERATURE * 3);
}
static void stepless_reduce_temperature(void)
{
    if(!get_is_provisioned())
        return;
    user_adjust_stepless_temerature(0, ONE_STEP_OF_TEMERATURE * 3);
}
static void stepless_add_lightness(void)
{
    if(!get_is_provisioned())
        return;
    user_adjust_stepless_lightness(1, ONE_STEP_OF_LIGHTNESS * 3);
}
static void stepless_reduce_lightness(void)
{
    if(!get_is_provisioned())
        return;
    user_adjust_stepless_lightness(0, ONE_STEP_OF_LIGHTNESS * 3);
}

static void hal_button_LPress_timer_cb(mesh_timer_t xTimer)
{
    volatile uint32_t gpio_result = 0;
    static volatile uint32_t lpress_counter = 0;

    //gpio_lpress_check &= gpio_value;
    //LOG(3, "hal_button_LPress_timer_cb gpio:%x counter:%x\n", gpio_lpress_check, lpress_counter);

    if((++lpress_counter > (CKECK_ONE_BUTTON_LONG_PRESS_TIME_MS)/HAL_TIMER_BUTTON_LPRESS_INTERVAL_MS) 
            && ((lpress_counter - (CKECK_ONE_BUTTON_LONG_PRESS_TIME_MS)/HAL_TIMER_BUTTON_LPRESS_INTERVAL_MS) % (HAL_TIMER_BUTTON_LPRESS_TIMEOUT_MS/HAL_TIMER_BUTTON_LPRESS_INTERVAL_MS + 1)) == 0) // timeout
    {
        gpio_result = check_button_is_pressed(gpio_val_array, HAL_TIMER_BUTTON_LPRESS_TIMEOUT_MS/HAL_TIMER_BUTTON_LPRESS_INTERVAL_MS, HAL_TIMER_BUTTON_LPRESS_TIMEOUT_MS/HAL_TIMER_BUTTON_LPRESS_INTERVAL_MS/2, gpio_lpress_check);

        //LOG(3, "gpio_result:%x\n", gpio_result);

        if(((WARM_BUTTON_PUSH) & gpio_result) == WARM_BUTTON_PUSH)
        {
            LOG(3, "hal_button_LPress_timer_cb:%d\n", __LINE__);
            press_send_pkt_flag = 1;
            mesh_run(stepless_reduce_temperature, portMAX_DELAY, true);
        }
        else if(((WHITE_BUTTON_PUSH) & gpio_result) == WHITE_BUTTON_PUSH)
        {
            LOG(3, "hal_button_LPress_timer_cb:%d\n", __LINE__);
            press_send_pkt_flag = 1;
            mesh_run(stepless_add_temperature, portMAX_DELAY, true);
        }
        else if(((REDUCE_LIGHTNESS_BUTTON_PUSH) & gpio_result) == REDUCE_LIGHTNESS_BUTTON_PUSH)
        {
            LOG(3, "hal_button_LPress_timer_cb:%d\n", __LINE__);
            press_send_pkt_flag = 1;
            mesh_run(stepless_reduce_lightness, portMAX_DELAY, true);
        }
        else if(((ADD_LIGHTNESS_BUTTON_PUSH) & gpio_result) == ADD_LIGHTNESS_BUTTON_PUSH)
        {
            LOG(3, "hal_button_LPress_timer_cb:%d\n", __LINE__);
            press_send_pkt_flag = 1;
            mesh_run(stepless_add_lightness, portMAX_DELAY, true);
        }
        else if(((ONOFF_BUTTON_PUSH) & gpio_result) == ONOFF_BUTTON_PUSH) // long press onoff button to reset system
        {
            LOG(3, "hal_button_LPress_timer_cb:%d\n", __LINE__);
            press_send_pkt_flag = 1;
            if(!get_is_provisioned())
                return;
            mesh_run(hal_button_onoff_cb, portMAX_DELAY, true);
        }
        else if(((MULTIFUNC_BUTTON_PUSH) & gpio_result) == MULTIFUNC_BUTTON_PUSH)
        {
            if(lpress_counter >= (HAL_TIMER_ONOFF_BUTTON_LPRESS_TIMEOUT_MS/HAL_TIMER_BUTTON_LPRESS_INTERVAL_MS)) {
                LOG(3, "long press to reset system...\n");
                mesh_run(hal_lpress_reset_system, portMAX_DELAY, true);
            }
        }else {
            if(!press_send_pkt_flag) {
                call_one_button_press_callback(gpio_lpress_check);
            }
            press_send_pkt_flag = 0;
            lpress_counter = 0;
            gpio_lpress_check = 0;
            xTimerStop(xTimerButtonLPress, portMAX_DELAY);
            hal_en_all_button();
        }
    }else {
        gpio_val_array[current_index++ % ARRAY_MAX] = (uint32_t)read_all_button_state();
        //LOG(3, "save2 gpio_val_array[%x]:%x\n", (current_index - 1)%ARRAY_MAX, gpio_val_array[(current_index-1) % ARRAY_MAX]);
        if(lpress_counter == (CKECK_ONE_BUTTON_PRESS_TIME_MS - HAL_DEBOUNCE_NM * HAL_TIMER_BUTTON_INTERVAL_MS)/HAL_TIMER_BUTTON_LPRESS_INTERVAL_MS) {
            uint32_t first_gpio_result_check = check_button_is_pressed(gpio_val_array, lpress_counter, lpress_counter - 3, gpio_lpress_check);
            gpio_result = check_button_is_pressed(gpio_val_array, 4, 2, gpio_lpress_check);

            //LOG(3, "2gpio_result:%x\n", gpio_result);

            if((ALL_BUTTON_PUSH & first_gpio_result_check) && (ALL_BUTTON_PUSH & gpio_result)) {
            }else {
                //LOG(3, "%s:%d gpio_lpress_check:%x\n", __func__, __LINE__, gpio_lpress_check);
                call_one_button_press_callback(gpio_lpress_check);
                press_send_pkt_flag = 0;
                lpress_counter = 0;
                gpio_lpress_check = 0;
                xTimerStop( xTimerButtonLPress, portMAX_DELAY);
                hal_en_all_button();
            }
        }
    }
}

static void hal_button_timer_cb(mesh_timer_t xTimer)
{
    static uint8_t enter_count = 0;
    uint32_t gpio_result = 0;
    //LOG(3, "hal_button_timer_cb\n");

    if(enter_count == 0) {
        current_index = 0;
    }

    if(enter_count++ < HAL_DEBOUNCE_NM)
    {
        gpio_val_array[current_index++ % ARRAY_MAX] = (uint32_t)read_all_button_state();
        //LOG(3, "save1 gpio_val_array[%x]:%x\n", (current_index-1) % ARRAY_MAX, gpio_val_array[(current_index-1) % ARRAY_MAX]);
        return;
    }
    else
    {
        gpio_result = check_button_is_pressed(gpio_val_array, HAL_DEBOUNCE_NM, 1, ALL_BUTTON_PUSH);

        if(((WARM_BUTTON_PUSH) & gpio_result) == WARM_BUTTON_PUSH)
        {
            //mesh_run(hal_button_warn_cb, portMAX_DELAY, true);
            send_pkt_type = BUTTON_GET_LIGHT_CTL_STATUS;
            gpio_lpress_check = WARM_BUTTON_PUSH;
        }
        else if(((WHITE_BUTTON_PUSH) & gpio_result) == WHITE_BUTTON_PUSH)
        {
            //mesh_run(hal_button_white_cb, portMAX_DELAY, true);
            send_pkt_type = BUTTON_GET_LIGHT_CTL_STATUS;
            gpio_lpress_check = WHITE_BUTTON_PUSH;
        }
        else if(((REDUCE_LIGHTNESS_BUTTON_PUSH) & gpio_result) == REDUCE_LIGHTNESS_BUTTON_PUSH)
        {
            //mesh_run(hal_button_reduce_lightness_cb, portMAX_DELAY, true);
            send_pkt_type = BUTTON_GET_LIGHT_LIGHTNESS_STATUS;
            gpio_lpress_check = REDUCE_LIGHTNESS_BUTTON_PUSH;
        }
        else if(((ADD_LIGHTNESS_BUTTON_PUSH) & gpio_result) == ADD_LIGHTNESS_BUTTON_PUSH)
        {
            //mesh_run(hal_button_add_lightness_cb,portMAX_DELAY, true);
            send_pkt_type = BUTTON_GET_LIGHT_LIGHTNESS_STATUS;
            gpio_lpress_check = ADD_LIGHTNESS_BUTTON_PUSH;
        }
        else if(((ONOFF_BUTTON_PUSH) & gpio_result) == ONOFF_BUTTON_PUSH)
        {
            //mesh_run(hal_button_onoff_cb,portMAX_DELAY, true);
            send_pkt_type = BUTTON_GET_GENERIC_ONOFF_STATUS;
            gpio_lpress_check = ONOFF_BUTTON_PUSH;
        }
        else if(((MULTIFUNC_BUTTON_PUSH) & gpio_result) == MULTIFUNC_BUTTON_PUSH)
        {
            //mesh_run(hal_button_multifunc_cb, portMAX_DELAY, true);
            send_pkt_type = BUTTON_GET_LIGHT_CTL_STATUS;
            gpio_lpress_check = MULTIFUNC_BUTTON_PUSH;
        } 

        LOG(3, "hal_button_timer_cb enter:%x gpio_lpress:%x gpio_result:%x\n", enter_count, gpio_lpress_check, gpio_result);
        enter_count = 0;

        xTimerStop( xTimerButton, portMAX_DELAY);

        if(gpio_lpress_check) {
            xTimerStart(xTimerButtonLPress, pdFALSE);

            if(get_is_provisioned() && (gpio_lpress_check != MULTIFUNC_BUTTON_PUSH) && (get_recv_current_status() != 1)) {
                set_recv_current_status(1);
                mesh_run(send_get_current_status_msg, portMAX_DELAY, true);
            }
        }else {
            mesh_run(call_mesh_sched_stop_scan, portMAX_DELAY, true);
            hal_en_all_button();
        }
    }
}

void hal_init_buttons(void)
{
    io_cfg_input(BTN_PIN_FOR_WARM);
    //io_cfg_input(BTN_PIN_FOR_WHITE);
    io_cfg_input(BTN_PIN_FOR_REDUCE_LIGHTNESS);
    io_cfg_input(BTN_PIN_FOR_ADD_LIGHTNESS);
    io_cfg_input(BTN_PIN_FOR_ONOFF);
    io_cfg_input(BTN_PIN_FOR_MULTIFUNC);

    //io_pin_pull_write(BTN_PIN_FOR_WARM, IO_PULL_DOWN);
    //io_pin_pull_write(BTN_PIN_FOR_WHITE, IO_PULL_UP);
    //io_pin_pull_write(BTN_PIN_FOR_REDUCE_LIGHTNESS, IO_PULL_UP);
    //io_pin_pull_write(BTN_PIN_FOR_ADD_LIGHTNESS, IO_PULL_UP);
    //io_pin_pull_write(BTN_PIN_FOR_ONOFF, IO_PULL_UP);
    //io_pin_pull_write(BTN_PIN_FOR_MULTIFUNC, IO_PULL_UP);

    io_ext_int_cfg(BTN_PIN_FOR_WARM, EXT_INT_TRIGGER_HIGH_LEVEL, hal_common_button_cb);
    io_ext_int_cfg(BTN_PIN_FOR_REDUCE_LIGHTNESS, EXT_INT_TRIGGER_LOW_LEVEL, hal_common_button_cb);
    io_ext_int_cfg(BTN_PIN_FOR_ADD_LIGHTNESS, EXT_INT_TRIGGER_LOW_LEVEL, hal_common_button_cb);
    io_ext_int_cfg(BTN_PIN_FOR_ONOFF, EXT_INT_TRIGGER_LOW_LEVEL, hal_common_button_cb);
    io_ext_int_cfg(BTN_PIN_FOR_MULTIFUNC, EXT_INT_TRIGGER_NEG_EDGE, hal_common_button_cb);
    hal_en_all_button();

    xTimerButton = xTimerCreateStatic( "ButtonTimer",
                                     pdMS_TO_TICKS(HAL_TIMER_BUTTON_INTERVAL_MS),
                                     pdTRUE,
                                     ( void * )0,
                                     hal_button_timer_cb,
                                     &xTimerButtonBuffers
                                     );
    xTimerButtonLPress = xTimerCreateStatic( "ButtonLPressTimer",
                                         pdMS_TO_TICKS(HAL_TIMER_BUTTON_LPRESS_INTERVAL_MS),
                                         pdTRUE,
                                         ( void * )0,
                                         hal_button_LPress_timer_cb,
                                         &xTimerButtonLPressBuffers
                                         );
}


void hal_heartbeat_init(void)
{
}

#define ONOFF_TIMER_TIME_MS 500
static mesh_timer_t onoff_timer;

void delete_onoff_timer(void)
{
    LOG(3, "delete_onoff_timer:%x\n", onoff_timer);
    if(onoff_timer) {
        mesh_timer_stop(onoff_timer);
        mesh_timer_delete(onoff_timer);
        onoff_timer = NULL;
    }

    io_pin_set(BTN_LED_INDICATOR_LIGHT);
}

static void user_onoff_timer_callback(mesh_timer_t xTimer)
{
    static uint8_t onoff = 1;
    LOG(3,"user_onoff_timer_callback onoff:%d\n", onoff);

    if(onoff) {
        io_pin_set(BTN_LED_INDICATOR_LIGHT);
    }else {
        io_pin_clear(BTN_LED_INDICATOR_LIGHT);
    }

    onoff = onoff ? 0 : 1;
}

void user_onoff_timer_init(void)
{
     onoff_timer = mesh_timer_create("onoff_timer", \
             pdMS_TO_TICKS(ONOFF_TIMER_TIME_MS), pdTRUE, onoff_timer, user_onoff_timer_callback);

     if(onoff_timer != NULL)

     {
         mesh_timer_start(onoff_timer);
     }
}

