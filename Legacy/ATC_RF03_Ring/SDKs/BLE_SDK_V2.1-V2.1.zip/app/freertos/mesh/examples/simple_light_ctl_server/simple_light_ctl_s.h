/**
 ****************************************************************************************
 *
 * @file   simple_light_ctl_s.h
 *
 * @brief  .
 *
 * @author  ZHAOYUNLIU
 * @date    2018-11-27 13:47
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup MESH_simple_light_ctl_s_API Mesh simple_light_ctl_s API
 * @ingroup MESH_API
 * @brief Mesh simple_light_ctl_s  API
 *
 * @{
 ****************************************************************************************
 */

#ifndef APP_FREERTOS_MESH_EXAMPLES_SIMPLE_LIGHT_CTL_SERVER_SIMPLE_LIGHT_CTL_S_H_
#define APP_FREERTOS_MESH_EXAMPLES_SIMPLE_LIGHT_CTL_SERVER_SIMPLE_LIGHT_CTL_S_H_

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "mesh_errors.h"
#include "sdk_mesh_config.h"
#include "sdk_mesh_definitions.h"

/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */


/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
void simple_light_ctl_server_init(void);



#endif /* APP_FREERTOS_MESH_EXAMPLES_SIMPLE_LIGHT_CTL_SERVER_SIMPLE_LIGHT_CTL_S_H_ */ 
/// @} MESH_simple_light_ctl_s_API

