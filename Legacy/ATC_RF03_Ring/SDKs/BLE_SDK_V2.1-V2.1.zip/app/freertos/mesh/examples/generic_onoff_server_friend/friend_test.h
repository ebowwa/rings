/**
 ****************************************************************************************
 *
 * @file   friend_test.h
 *
 * @brief  .
 *
 * @author  jiachuang
 * @date    2019-07-25 15:26
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) BlueX Microelectronics 2019
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup MESH_fnd_lp_test_API Mesh fnd_lp_test API
 * @ingroup MESH_API
 * @brief Mesh fnd_lp_test  API
 *
 * @{
 ****************************************************************************************
 */

#ifndef APP_FREERTOS_MESH_EXAMPLES_SIMPLE_GENERIC_ONOFF_SERVER_FRIEND_TEST_TEST_H_
#define APP_FREERTOS_MESH_EXAMPLES_SIMPLE_GENERIC_ONOFF_SERVER_FRIEND_TEST_TEST_H_

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "mesh_errors.h"
#include "sdk_mesh_config.h"
#include "sdk_mesh_definitions.h"
#include <stdint.h>

/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */


/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */


/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
void button_action(uint8_t button_idx);





#endif /* APP_FREERTOS_MESH_EXAMPLES_SIMPLE_GENERIC_ONOFF_SERVER_FND_LP_TEST_H_ */ 
/// @} MESH_fnd_lp_test_API

