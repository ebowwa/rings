/**
 ****************************************************************************************
 *
 * @file   mesh_app.c
 *
 * @brief  .
 *
 * @author  Hui Chen
 * @date    2018-09-25 17:20
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "osapp_config.h"
//mesh platform
#include "mesh_errors.h"
#include "sdk_mesh_config.h"
#include "sdk_mesh_definitions.h"
#include "mesh_core_api.h"
//app
#include "node_setup.h"
#include "mesh_app_hal.h"
//tools
#include "co_utils.h"
#include <stdbool.h>
#include "string.h"
//feature
#include "node_save.h"
//model
#include "config_server_events_api.h"
#include "model_servers_events_api.h"
#include "config_server.h"
#include "generic_onoff_server.h"
#include "mesh_env.h"
#include "mesh_node_base.h"
#include "proxy_s.h"
//hal
#include "mesh_app_hal.h"
#include "health_server.h"
#include "beacon.h"
/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

#define APP_KEY_MAX 3
#define SUB_ADDR_MAX 4
mesh_addr_t sub_addr_list[SUB_ADDR_MAX];


DEF_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_0, APP_KEY_MAX);
DEF_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_1, APP_KEY_MAX);

DEF_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_0, APP_KEY_MAX);
DEF_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_1, APP_KEY_MAX);

DEF_HEALTH_SERVER_MODEL(health_server_0, APP_KEY_MAX);
DEF_HEALTH_SERVER_MODEL(health_server_1, APP_KEY_MAX);

void model_status_publish(void)
{
}

void user_health_attention_0_evt_cb(const mesh_model_evt_t *p_evt)
{
    uint16_t attention_value = p_evt->params.model_value_set.target_value;
    LOG(3, "user_health_attention_0_evt_cb attention:%x\n", attention_value);
    if(attention_value) {

    }else {

    }
}
void user_health_attention_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    uint16_t attention_value = p_evt->params.model_value_set.target_value;
    LOG(3, "user_health_attention_1_evt_cb attention:%x\n", attention_value);
    if(attention_value) {

    }else {

    }
}

void user_onoff_0_evt_cb(const mesh_model_evt_t * p_evt)
{
    switch(p_evt->type.onoff_type)
    {
        case ONOFF_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED1=%d!!!\n",p_evt->params.model_value_set.target_value);
            hal_set_led(1, p_evt->params.model_value_set.target_value);
            generic_onoff_server_0.msg_format.present_onoff = p_evt->params.model_value_set.target_value;
            break;
        case ONOFF_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"ONOFF_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}
void user_onoff_1_evt_cb(const mesh_model_evt_t * p_evt)
{
    switch(p_evt->type.onoff_type)
    {
        case ONOFF_MODEL_EVT_SET:
            LOG(LOG_LVL_INFO,"!!!LED2=%d!!!\n",p_evt->params.model_value_set.target_value);
            hal_set_led(2, p_evt->params.model_value_set.target_value);
            generic_onoff_server_1.msg_format.present_onoff = p_evt->params.model_value_set.target_value;
            break;
        case ONOFF_MODEL_EVT_GET:
            LOG(LOG_LVL_INFO,"ONOFF_MODEL_EVT_GET!!!\n");
            break;
        default:
            LOG(LOG_LVL_INFO,"EVT NOT FOUND!!!\n");
            break;
    }
}

void user_config_server_evt_cb(config_server_evt_type_t type, config_server_evt_param_t*p_param)
{
    LOG(LOG_LVL_INFO , "user_config_server_evt_cb=%d\n",type);

    switch(type)
    {
        case CONFIG_SERVER_EVT_RELAY_SET :
        {
            hal_relay_led_set(p_param->relay_set.enabled);
        }
        break;
        default:break;
    }
}



void mesh_app_server_init(void)
{
    memset(&generic_onoff_server_0, 0, sizeof(generic_onoff_server_t)); 
    memset(&generic_onoff_server_1, 0, sizeof(generic_onoff_server_t)); 

    memset(&generic_transition_server_0, 0, sizeof(generic_transition_server_t));
    memset(&generic_transition_server_1, 0, sizeof(generic_transition_server_t));

    memset(&health_server_0, 0, sizeof(health_server_t));
    memset(&health_server_1, 0, sizeof(health_server_t));

    //1.init model
    INIT_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_onoff_0_evt_cb);
    INIT_GENERIC_ONOFF_SERVER_MODEL(generic_onoff_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_onoff_1_evt_cb);

    INIT_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, NULL);
    INIT_GENERIC_TRANSITION_SERVER_MODEL(generic_transition_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, NULL);

    INIT_HEALTH_SERVER_MODEL(health_server_0, APP_KEY_MAX, 0, sub_addr_list, SUB_ADDR_MAX, user_health_attention_0_evt_cb);
    INIT_HEALTH_SERVER_MODEL(health_server_1, APP_KEY_MAX, 1, sub_addr_list, SUB_ADDR_MAX, user_health_attention_1_evt_cb);

    //3.set initial state
    health_server_0.company_id = MESH_PARAM_CID;
    health_server_1.company_id = MESH_PARAM_CID;

    generic_onoff_server_0.msg_format.present_onoff = 1;
    generic_onoff_server_1.msg_format.present_onoff = 1;
    generic_onoff_server_0.delay_trans_timer = model_common_delay_trans_timer_get_from_element_id(0);
    generic_onoff_server_1.delay_trans_timer = model_common_delay_trans_timer_get_from_element_id(1);

    //4.Register config server event callbacks
    regisite_config_server_evt_cb(user_config_server_evt_cb);

    beacon_start();
}





//init user models
void mesh_node_setup(void)
{
    //system init node-element-model tree
    mesh_core_params_t param;
    param.role = MESH_ROLE_CONFIG_SERVER;
    mesh_core_params_set(MESH_CORE_PARAM_MESH_ROLES , &param);
    //init user model list
    mesh_app_server_init();
#ifdef ENABLE_LOW_POWER_TEST
    low_power_test_init();
#endif
}

