/**
 ****************************************************************************************
 *
 * @file   mesh_user_main.h
 *
 * @brief  .
 *
 * @author  ZHAOYUNLIU
 * @date    2018-11-27 13:46
 * @version <0.0.0.1>
 *
 * @license 
 *              Copyright (C) Apollo 2018
 *                         ALL Right Reserved.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup MESH_mesh_user_main_API Mesh mesh_user_main API
 * @ingroup MESH_API
 * @brief Mesh mesh_user_main  API
 *
 * @{
 ****************************************************************************************
 */

#ifndef APP_FREERTOS_MESH_EXAMPLES_SIMPLE_LIGHT_LIGHTNESS_SERVER_MESH_USER_MAIN_H_
#define APP_FREERTOS_MESH_EXAMPLES_SIMPLE_LIGHT_LIGHTNESS_SERVER_MESH_USER_MAIN_H_

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "mesh_errors.h"
#include "sdk_mesh_config.h"
#include "sdk_mesh_definitions.h"

/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */


/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
/**
 ****************************************************************************************
 * @brief   user init function
 * @return  void
 ****************************************************************************************
 */
void mesh_user_main_init(void);



#endif /* APP_FREERTOS_MESH_EXAMPLES_SIMPLE_LIGHT_LIGHTNESS_SERVER_MESH_USER_MAIN_H_ */ 
/// @} MESH_mesh_user_main_API

